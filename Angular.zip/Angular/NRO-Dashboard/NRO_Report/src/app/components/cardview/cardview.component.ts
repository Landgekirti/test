import { Component, OnInit,Input } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
import { DetailsService } from './details.service';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { DetailsTableComponent } from './details-table/details-table.component'
@Component({
  selector: 'app-cardview',
  templateUrl: './cardview.component.html',
  styleUrls: ['./cardview.component.scss']
})
export class CardviewComponent implements OnInit {
  @Input() oInputCard
  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService, public detailsService:DetailsService, private MatDialog: MatDialog){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    $(function(){
          function equalHeight(){
              var heightArray = $(".card-box").map( function(){
                  return  $(this).height();
              }).get();
             
              var maxHeight = Math.max.apply( Math, heightArray);
                  $(".card-box").height(maxHeight);
              }
          equalHeight();
    });
    
    
    //this.getRegionBasedData(this.oInputCard);
  }
  
  ngAfterViewInit(){
    
  }

  reqObj
  stateDetails
  getRegionBasedData(data){
    this.reqObj={
      "RegionCode": data
    }
    this.httpService.getStateSummary(this.reqObj).subscribe((response) => {
      
      this.stateDetails=response;
      this.stateDetails=this.stateDetails.Table
    }, (error) => {
        
    }
    );
  }


  displayDetails()
  {
    
    this.detailsService.stateData=this.oInputCard
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass='dialog-lg';
    let dialogRef= this.MatDialog.open(DetailsTableComponent, dialogConfig);
    dialogRef.disableClose=true;
    dialogRef.afterClosed().subscribe((resp)=>
    {
            
    })
  }
}
