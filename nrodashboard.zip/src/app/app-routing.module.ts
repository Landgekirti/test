import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { SummaryComponent } from './components/summary/summary.component';
import { ProposalComponent } from './components/proposal/proposal.component';
import { AnalyticsComponent } from './components/analytics/analytics.component';
import { DonutChartComponent } from './components/common/donut-chart/donut-chart.component';
import { NroTableComponent } from './components/common/nro-table/nro-table.component';
import { CardviewComponent } from './components/cardview/cardview.component';
import { PieChartComponent } from './components/common/pie-chart/pie-chart.component';
import { SummarybarComponent } from './components/summarybar/summarybar.component';
import { GridviewComponent } from './components/gridview/gridview.component';
import { SummaryMoreComponent } from './components/summary-more/summary-more.component';
import { MapViewComponent } from './components/map-view/map-view.component';
import { StatusComponent } from './components/status/status.component';
import { DocketComponent } from './components/docket/docket.component';
import { FeildTableComponent } from './components/snapshot/feild-table/feild-table.component';
import { PopUpTableComponent } from './components/gridview/pop-up-table/pop-up-table.component';
import { QualitativeReportComponent } from './components/analytics/snapshot/qualitative-report/qualitative-report.component';
import { DetailsTableComponent } from './components/cardview/details-table/details-table.component';
import { RegionDetailsComponent } from './components/summary/region-details/region-details.component';

const routes: Routes = [{ path: '', component: SummaryComponent, pathMatch: 'full' },
                        {path: 'nro-summary', component:SummaryComponent},
                        {path: 'nro-proposal', component:ProposalComponent},
                        {path: 'nro-analytics', component:AnalyticsComponent},
                        {path: 'nro-donutchart', component:DonutChartComponent},
                        {path: 'nro-table', component:NroTableComponent},
                        {path: 'nro-cardview', component:CardviewComponent},
                        {path: 'nro-piechart', component:PieChartComponent},
                        {path: 'nro-summarybar', component:SummarybarComponent},
                        {path: 'nro-gridview', component:GridviewComponent},
                        {path: 'nro-summarymore', component:SummaryMoreComponent},
                        {path: 'nro-map', component:MapViewComponent},
                        {path: 'nro-status', component:StatusComponent},
                        {path: 'nro-docket', component:DocketComponent},
                        {path: 'nro-feild', component:FeildTableComponent},
                        {path: 'nro-tatable', component:PopUpTableComponent},
                        {path: 'nro-snapshot-qaReport', component:QualitativeReportComponent},
                        {path: 'nro-details-table', component:DetailsTableComponent},
                        {path: 'nro-region-table', component:RegionDetailsComponent},
                       ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ]
})
export class AppRoutingModule { }
