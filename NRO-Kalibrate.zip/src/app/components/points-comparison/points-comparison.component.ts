import { Component, OnInit } from '@angular/core';
import { getData } from '../Services/getData.service'
import { LocalSevice } from './../localservice.service'
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-points-comparison',
  templateUrl: './points-comparison.component.html',
  styleUrls: ['./points-comparison.component.scss']
})
export class PointsComparisonComponent implements OnInit {
  allPoints; allProposalPoints;
  proposalNumber: String = null;
  segmentDynamicInput: string = null;

  constructor(private getData: getData,
    private localSevice: LocalSevice,
    public dialogRef: MatDialogRef<PointsComparisonComponent>) { }

  ngOnInit() {
    this.segmentDynamicInput = this.localSevice.SegmentIds;
    this.proposalNumber = this.localSevice.proposalNumber;
    this.getPoints();
    this.getProposalPoints();
  }

  getPoints() {
    this.getData.GetPointsbySegmentId(this.segmentDynamicInput).subscribe(data => {
      this.allPoints = data.Table
    })
  }

  getProposalPoints() {
    this.getData.GetPointsbyProposal(this.proposalNumber).subscribe(data => {
      this.allProposalPoints = data.Table
    })
  }

  onClose() {
    this.dialogRef.close();
  }
}
