import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import { Component, OnInit } from '@angular/core';
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { HttpCallsService } from '../../../services/http-calls.service';

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end


@Component({
  selector: 'app-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.scss']
})
export class DonutChartComponent implements OnInit {
  chartData
  radius
  width
  value
  category
  divId
  constructor(public httpService:HttpCallsService) {
    //this.chartData=
    this.radius=60;
    this.width=350;
    this.value="TotalProposalCount";
    this.category="RegionName"
    this.divId ="chartdivdonut"
   }

  ngOnInit() {
    //this.genrateChart();
    this.getRegionData();
    
  }

  logoDiaplayChange(){
    var logo = document.getElementsByTagName('title')[1].parentElement;
    
    logo.style.display = "none";
  }
  
  genrateChart(data){
    
    let chart = am4core.create(this.divId, am4charts.PieChart);
    // Add data
    let colorSet = new am4core.ColorSet();
    chart.data = data;
   // Set inner radius
    chart.innerRadius = am4core.percent(this.radius);
    chart.width = this.width;
    // Add and configure Series
    let pieSeries = chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = this.value;
    pieSeries.dataFields.category = this.category;
    pieSeries.slices.template.stroke = am4core.color("#fff");
    pieSeries.slices.template.strokeWidth = 2;
    pieSeries.slices.template.strokeOpacity = 1;
    // This creates initial animation
    pieSeries.hiddenState.properties.opacity = 5;
    pieSeries.hiddenState.properties.endAngle = -90;
    pieSeries.hiddenState.properties.startAngle = -90;
    pieSeries.alignLabels = false;
    pieSeries.labels.template.text = '';
    //pieSeries.labels.template.radius = am4core.percent(-40);
    //pieSeries.labels.template.fill = am4core.color("white");
    pieSeries.colors.list = [
      am4core.color("#608bfe"),
      am4core.color("#3bcac6"),
      am4core.color("#ffbb4b"),
      am4core.color("#5cd049"),
      am4core.color("#FFC75F"),
      am4core.color("#F9F871"),
    ];

    chart.legend = new am4charts.Legend();
    chart.legend.useDefaultMarker = true;
    let marker = chart.legend.markers.template.children.getIndex(0);
    marker.width = 15;
    marker.height = 15;
    //marker.cornerRadius(12, 12, 12, 12);
    marker.strokeWidth = 2;
    marker.strokeOpacity = 1;
    marker.stroke = am4core.color("#ccc");
    // let watermark = new am4core.Label();
    // watermark.text = " ";
    // chart.children.push(watermark);
    this.logoDiaplayChange();
  }

  reportDetails
  obj
getRegionData(){
  this.obj={
    "RegionCode": "North"
  }
    this.httpService.getRegionSummary(this.obj).subscribe((response) => {
      
      
      this.reportDetails=response;
      this.reportDetails=this.reportDetails.Table;
      this.genrateChart(this.reportDetails);
    }, (error) => {
        
    }
    );
  }

  }