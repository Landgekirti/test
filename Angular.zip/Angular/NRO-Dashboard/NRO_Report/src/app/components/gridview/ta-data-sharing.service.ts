import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TaDataSharingService {

  constructor() { }
  private _taData: any[]=[];

  get TaData(): any[] {
    return this._taData;
  }
  set TaData(obj: any[]) {
    this._taData = obj;
  }
}
