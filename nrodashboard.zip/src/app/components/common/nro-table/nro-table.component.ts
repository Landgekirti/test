import { Component, OnInit, ViewChild, Input, EventEmitter, Output, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { NroTableModel } from './nro-table.model';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-nro-table',
  templateUrl: './nro-table.component.html',
  styleUrls: ['./nro-table.component.scss']
})

export class NroTableComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @Input() oInputRilTableModel: NroTableModel;  
  @Input() oChangeTrigger:number;
  @Output() onDelete = new EventEmitter<any>();
  @Output() onAdd = new EventEmitter<any>();
  @Output() onApproval = new EventEmitter<any>();
  @Output() onSave = new EventEmitter<any>();
  @Output() onFetchData = new EventEmitter<any>();
  @Output() onCalculate = new EventEmitter<any>();
  @Output() onDeleteRow = new EventEmitter<any>();
  @Output() onEditRow = new EventEmitter<any>();
  @Output() onDisplayRow = new EventEmitter<any>();
  @Output() onDownload = new EventEmitter<any>();
  /*certificate*/
  @Output() onDisplayCertificate = new EventEmitter<any>();
  /*categorize*/
  @Output() onCategorize = new EventEmitter<any>();
  /*DownloadCertificate*/
  @Output() onDownloadCertifi = new EventEmitter<any>();
  @Output() onStatus = new EventEmitter<any>();

  _oRilTableModel: NroTableModel;  
  selection = new SelectionModel(true, []);  
  _oDataSource;
  _toolTip :string="";
  objFilterValue:any;
  objFilterValue1:any;
  firstFilter = new FormControl();
  secondFilter = new FormControl();
  thirdFilter = new FormControl();
  fourthFilter = new FormControl();
  fifthFilter = new FormControl();
  sixthFilter = new FormControl();
  globalFilter='';
  filteredValues={"StateCode":'', "TotalProposalCount":'', "CompletedCount":'', "SubmittedCount":'', "QueryCount":'', "RejectedCount":'', "AvgTASizeCat":'', "AvgPotentialVolCat":''}
  constructor(private changeDetectorRefs: ChangeDetectorRef) { }

  ngOnChanges(changes: SimpleChanges) {
    if(this._oRilTableModel!=null && this._oRilTableModel.selectedRecords !=undefined )
      this._oRilTableModel.selectedRecords = [];
    
    this.bindTable();
    if(this.objFilterValue!="" && this.objFilterValue!=undefined )
    {
    this.applyFilter(this.objFilterValue)
    }

    if(this.objFilterValue1!="" && this.objFilterValue1!=undefined )
    {
    this.applyFilter(this.objFilterValue1)
    }
    
    this.firstFilter.valueChanges.subscribe((positionFilterValue) => {
      this.filteredValues['StateCode'] = positionFilterValue;
      
      this._oDataSource.filter = JSON.stringify(this.filteredValues);
      
    });

    this._oDataSource.filterPredicate = this.customFilterPredicate();
  }

  bindTable()
  {
    //this._oRilTableModel.selectedRecords=[]
    this._oDataSource = new MatTableDataSource(this.oInputRilTableModel.dataSource);
    this._oDataSource.paginator = this.paginator;
    this._oDataSource.sort = this.sort;    
  }

  ngOnInit() {
    this._oRilTableModel = new NroTableModel();

    this.bindTable();
    
  }

  getToolTipData(row: any) {
    this._toolTip = "";
    let val = `${row.tooltip}`;
    if(val != "undefined")
    {
      this._toolTip = `${row.tooltip}`;
    }
}

  onDeleteBtn() {
    
    this.onDelete.emit(this._oRilTableModel.selectedRecords);  
  }

  onAddBtn() {
    this.onAdd.emit();
  }

  onApprovalBtn() {
    this.onApproval.emit(this._oRilTableModel.selectedRecords);
  }

  onDownloadBtn() {
    this.onDownload.emit(this._oRilTableModel);
  }

  onCalculateBtn() {
    this.onCalculate.emit(this._oRilTableModel);
  }

  onFetchDataBtn() {
    this.onFetchData.emit(this._oRilTableModel);
  }

  onSaveBtn() {
    this.onSave.emit(this._oRilTableModel);
  }

  onRowDelete(row) {    
    this.onDeleteRow.emit(row);
  }

  onRowEdit(row) {
    this.onEditRow.emit(row);
  }

  onRowDisplay(row) {
    this.onDisplayRow.emit(row);
  }
/*certificate*/
  oncertiDisplay(row){
    this.onDisplayCertificate.emit(row);
  }
/*categorize*/  
  onCategorizeBtn() {
    this.onCategorize.emit(this._oRilTableModel);
  } 
/*download certificate*/
  onDownloadCertificate(row) {
    this.onDownloadCertifi.emit(row);
  }
/*status*/
onstatusClick(row){
    this.onStatus.emit(row);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    if (this._oDataSource.data != undefined && this._oDataSource.data != null) {
          
      let pageSize: number = this.paginator.pageSize;
      const numSelected = this.selection.selected.length;
      const numRows = this._oDataSource.data.length;
      
      if (numRows < pageSize || this.oInputRilTableModel.isSelectAll) {
        pageSize = numRows;
      }
      return numSelected === pageSize;
    }
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    
    if (this.isAllSelected()) {
      
      this.selection.clear();
      this._oRilTableModel.selectedRecords = [];
    }
    else {
      
      this._oRilTableModel.selectedRecords = [];

      let pageSize: number = this.paginator.pageSize;
      let iCount: number = 1;
      this.selection.clear();
      for (var n = 0; n < this._oDataSource.data.length; n++) {
        if (n > pageSize - 1 && this.oInputRilTableModel.isSelectAll == false) {
          break;
        }
        let row = this._oDataSource.data[n];
        this.selection.select(row);
        this._oRilTableModel.selectedRecords.push(row);
      }
      
    }
  }

  applyFilter(filterValue: string) {
    filterValue = String(filterValue);
    
    this.objFilterValue=filterValue;
    
    this._oDataSource.filter = filterValue.trim().toLowerCase();
    
    if (this._oDataSource.paginator) {
      this._oDataSource.paginator.firstPage();
    }
  }

  // applyFilter1(filterValue1: string) {
  //   filterValue1 = String(filterValue1);
  
  //   this.objFilterValue1=filterValue1;
  
  //   this._oDataSource.filteredData.filter = filterValue1.trim().toLowerCase();
    
  //   if (this._oDataSource.paginator) {
  //     this._oDataSource.paginator.firstPage();
  //   }
  // }

  itemclick(row, myCheckBox) {
    try {
      if (!myCheckBox.checked == true) {

        this._oRilTableModel.selectedRecords.push(row);
      }
      if (!myCheckBox.checked == false) {
        var index = this._oRilTableModel.selectedRecords.indexOf(row);
        var i = 0;
        this._oRilTableModel.selectedRecords.forEach(element => {
          //if (element.id == row._id) {
            if (i == index) {
            this._oRilTableModel.selectedRecords.splice(i, 1)
          }
          i++;
        });
      }
      

    } catch (error) {
      
    }
    finally {
    }
  }

  keyPressHandler(e) {
    if (e.keyCode === 13) {
      e.preventDefault();
      e.stopPropagation();
    }
  }

  customFilterPredicate() {
    const myFilterPredicate = (data, filter: string): boolean => {
      var globalMatch = !this.globalFilter;

      if (this.globalFilter) {
        // search all text fields
        globalMatch = data.name.toString().trim().toLowerCase().indexOf(this.globalFilter.toLowerCase()) !== -1;
      }

      if (!globalMatch) {
        return;
      }

      let searchString = JSON.parse(filter);
      return data.position.toString().trim().indexOf(searchString.position) !== -1 &&
        data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1;
    }
    return myFilterPredicate;
  }
}


