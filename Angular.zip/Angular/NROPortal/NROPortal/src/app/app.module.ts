import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { HttpClientModule, HttpParams } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './views/layout/header/header.component';
import { TitleCasePipe } from '@angular/common';

// Bootstrap Components
import { AppBootstrapModule } from './app-bootstrap/app-bootstrap.module';

// Material Components
import { AppMaterialModule } from './app-material/app-material.module';

// Other Components  
import { OwlModule } from 'ngx-owl-carousel';
import { DataTablesModule } from 'angular-datatables';

import { FooterComponent } from './views/layout/footer/footer.component';
import { SidenavComponent } from './views/layout/sidenav/sidenav.component';
import { HomeComponent } from './views/home/home.component';
import { LoginComponent } from './views/login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidenavComponent,
    HomeComponent,
    LoginComponent,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AppBootstrapModule,
    AppMaterialModule,
    OwlModule,
    DataTablesModule
  ],
  providers: [CookieService, TitleCasePipe],
  bootstrap: [AppComponent]
})
export class AppModule {}
