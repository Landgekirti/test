import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpParams, HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';
import { SegmentDetailComponent } from '../../components/segment-details/segment-details.component';
import { environment } from 'src/environments/environment'

@Injectable({ providedIn: 'root' })
export class getData {
    response;Url;
    //Url = 'http://localhost:28004/Api'; //Localhost 
    // Url = 'http://10.131.133.21/NROKalibrateService/Api'; //dev   
    //Url = 'http://10.144.16.173/NROKalibrateService/Api'; //QA
    //Url = 'http://10.26.38.19/NROKalibrateService/Api' //devAzure
    headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });

    constructor(private httpclient: HttpClient) {
        this.Url = environment.ApiUrl;
     }

    UploadSegmentExcel(formData: FormData) {
        let headers = new HttpHeaders();

        headers.append('Content-Type', 'multipart/form-data');
        headers.append('Accespt', 'application/json');

        const httpOptions = { headers: headers };
        return this.httpclient.post(this.Url + '/SegmentExcel/UploadExcel', formData, httpOptions)
    }

    UploadPointExcel(formData: FormData) {
        let headers = new HttpHeaders();

        headers.append('Content-Type', 'multipart/form-data');
        headers.append('Accespt', 'application/json');

        const httpOptions = { headers: headers };
        return this.httpclient.post(this.Url + '/PointExcel/UploadPointExcel', formData, httpOptions)
    }

    getState(): Observable<any> {
        let data = new HttpParams().set('filterType', 'getStates')
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetStates', { body: data, headers: this.headers });
    }

    getDistrict(stateInput): Observable<any> {
        let data = new HttpParams().set('filterType', 'getDistricts').append('filterValue', stateInput)
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetStates', { body: data, headers: this.headers });
    }

    GetSegmentData(): Observable<any> {
        let data = new HttpParams().set('filterType', 'getdata')
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetSegmentDatabyStatesandDistricts', { body: data, headers: this.headers });
    }

    GetSegmentDatabyState(stateInput): Observable<any> {
        let data = new HttpParams().set('filterType', 'getdatabyState').append('filterValue', stateInput)
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetSegmentDatabyStatesandDistricts', { body: data, headers: this.headers });
    }

    GetSegmentDatabyDistrict(DistrictInput): Observable<any> {
        let data = new HttpParams().set('filterType', 'getdatabyDistricts').append('filterValue', DistrictInput)
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetSegmentDatabyStatesandDistricts', { body: data, headers: this.headers });
    }

    GetPointsbySegmentId(segmentIdInput): Observable<any> {
        let data = new HttpParams().set('segmentIdInput', segmentIdInput)
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/GetPointsDataBySegmentId', { body: data, headers: this.headers });
    }

    GetProposaldatabyPoints(pointInput): Observable<any> {
        let data = new HttpParams().set('pointInput', pointInput)
        return this.httpclient.request('POST', this.Url + '/getPointssData/GetProposalsData', { body: data, headers: this.headers });
    }

    GetUserRole(UserName): Observable<any> {
        let data = new HttpParams().set('UserName', UserName)
        return this.httpclient.request('POST', this.Url + '/getPointssData/GetUserRoleForKalibrate', { body: data, headers: this.headers });
    }

    GetProposalbyStates(state): Observable<any> {
        let data = new HttpParams().set('stateInput', state)
        return this.httpclient.request('POST', this.Url + '/getPointssData/GetProposalsDatabyState', { body: data, headers: this.headers });
    }

    GetPointsbyProposal(proposalNumber): Observable<any> {
        let data = new HttpParams().set('ProposalNumber', proposalNumber)
        return this.httpclient.request('POST', this.Url + '/getPointssData/spGetProposalDataforKalibrate', { body: data, headers: this.headers })
    }

    SaveKalibrateDetails(segmentInput, proposalNumber): Observable<any> {
        let data = new HttpParams().set('proposalNumber', proposalNumber).append('segmentIds', segmentInput);
        return this.httpclient.request('POST', this.Url + '/getPointssData/saveKalibrateDetailsforKalibrate', { body: data, headers: this.headers })
    }

    CheckSegmentsState(segmentInput, stateInput): Observable<any> {
        let data = new HttpParams().set('segmentIdInput', segmentInput).append('stateInput', stateInput);
        return this.httpclient.request('POST', this.Url + '/getSegmentsData/CheckSegmentsState', { body: data, headers: this.headers })
    }

}