import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeildTableComponent } from './feild-table.component';

describe('FeildTableComponent', () => {
  let component: FeildTableComponent;
  let fixture: ComponentFixture<FeildTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeildTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeildTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
