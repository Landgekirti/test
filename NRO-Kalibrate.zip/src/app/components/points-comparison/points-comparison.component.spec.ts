import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointsComparisonComponent } from './points-comparison.component';

describe('PointsComparisonComponent', () => {
  let component: PointsComparisonComponent;
  let fixture: ComponentFixture<PointsComparisonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointsComparisonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointsComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
