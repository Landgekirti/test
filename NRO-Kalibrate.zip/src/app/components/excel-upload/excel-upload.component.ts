import { Component, OnInit, ViewChild } from '@angular/core';
import { LocalSevice } from './../localservice.service'
import { getData } from '../Services/getData.service';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { MessageService } from './../common/message.service'

@Component({
  selector: 'app-excel-upload',
  templateUrl: './excel-upload.component.html',
  styleUrls: ['./excel-upload.component.scss']
})
export class ExcelUploadComponent implements OnInit {
  @ViewChild('fileInput') fileInput;
  @ViewChild('fileInput') fileInputPoints;
  segmentmessage: string;
  Pointmessage: string;
  agree: boolean = true;
  constructor(private getSegmentsData: getData,
    public dialogRef: MatDialogRef<ExcelUploadComponent>,
    private MessageService: MessageService) { }

  ngOnInit() { }

  segmentUpload() {
    let formData = new FormData();
    formData.append('upload', this.fileInput.nativeElement.files[0])

    this.getSegmentsData.UploadSegmentExcel(formData).subscribe(result => {
      this.segmentmessage = result.toString();
    }, (error) => {
      this.MessageService.fileUploadnotification();
    });
  }

  pointUpload() {
    let formData = new FormData();
    formData.append('upload', this.fileInputPoints.nativeElement.files[0])

    this.getSegmentsData.UploadPointExcel(formData).subscribe(result => {
      this.Pointmessage = result.toString();
    }, (error) => {
      this.MessageService.fileUploadnotification();
    });
  }

  onClose() {
    this.dialogRef.close();
  }

  onAgree() {
    if (this.agree == true) {
      this.agree = false
    }
    else {
      this.agree = true
    }
  }
}
