﻿using ExcelDataReader;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace SegmentUploadWebApp.Controllers
{
     [RoutePrefix("Api/PointExcel")] 
    public class PointController : ApiController
    {
        [Route("UploadPointExcel")]
        [HttpPost]
        public string ExcelUpload()
        {
            string message = "";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Current.Request;
            using (dbKalibratePointEntities objEntity = new dbKalibratePointEntities())
            {

                if (httpRequest.Files.Count > 0)
                {
                    HttpPostedFile file = httpRequest.Files[0];
                    Stream stream = file.InputStream;

                    IExcelDataReader reader = null;

                    if (file.FileName.EndsWith(".xls"))
                    {
                        reader = ExcelReaderFactory.CreateBinaryReader(stream);
                    }
                    else if (file.FileName.EndsWith(".xlsx"))
                    {
                        reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    }
                    else
                    {
                        message = "This file format is not supported";
                    }

                    DataSet excelRecords = reader.AsDataSet();
                    reader.Close();

                    var getSegment = excelRecords.Tables[0];
                    for (int i = 1; i < getSegment.Rows.Count; i++)
                    {
                        KalibratePointStaging objUser = new KalibratePointStaging();
                        objUser.SegmentId = System.Convert.ToInt32(getSegment.Rows[i][0]);
                        objUser.PointID = System.Convert.ToInt32(getSegment.Rows[i][1]);
                        objUser.OutletName = getSegment.Rows[i][2].ToString();
                        objUser.PetrolBrand = getSegment.Rows[i][3].ToString();
                        objUser.PointRanking = System.Convert.ToDecimal(getSegment.Rows[i][4]);
                        objUser.Latitude = System.Convert.ToDecimal(getSegment.Rows[i][5]);
                        objUser.Longitude = System.Convert.ToDecimal(getSegment.Rows[i][6]);
                        objUser.PetrolVolume = System.Convert.ToInt32(getSegment.Rows[i][7]);
                        objUser.DieselVolume = System.Convert.ToInt32(getSegment.Rows[i][8]);
                        objUser.TotalMoFuel = System.Convert.ToInt32(getSegment.Rows[i][9]);
                        objUser.LXMarketID = System.Convert.ToInt32(getSegment.Rows[i][10]);
                        objUser.SegmentRanking = System.Convert.ToDecimal(getSegment.Rows[i][11]);
                        objUser.HighwayName = getSegment.Rows[i][12].ToString();
                        objUser.State = getSegment.Rows[i][13].ToString();
                        objUser.District = getSegment.Rows[i][14].ToString();
                        objUser.City = getSegment.Rows[i][15].ToString();
                        objUser.PriRoadName = getSegment.Rows[i][16].ToString();
                        objUser.DieselBrand = getSegment.Rows[i][17].ToString();
                        objUser.SegmentMidpointAddress = getSegment.Rows[i][18].ToString();
                        System.DateTime today = System.DateTime.Today; // As DateTime
                        objUser.UploadedOn = today;
                        objUser.Note1 = null;
                        objUser.Note2 = null;

                        objEntity.KalibratePointStagings.Add(objUser);

                    }

                    int output = objEntity.SaveChanges();
                    if (output > 0)
                    {
                        message = "Excel file has been successfully uploaded";
                    }
                    else
                    {
                        message = "Excel file uploaded has faild";
                    }

                }

                else
                {
                    result = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            return message;
        }

        [Route("PointDetails")]
        [HttpGet]
        public List<KalibratePointStaging> BindUser()
        {
            List<KalibratePointStaging> lstUser = new List<KalibratePointStaging>();
            using (dbKalibratePointEntities objEntity = new dbKalibratePointEntities())
            {
                lstUser = objEntity.KalibratePointStagings.ToList();
            }
            return lstUser;
        }  
    }
}
