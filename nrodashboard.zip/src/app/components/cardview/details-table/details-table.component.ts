import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { DetailsService } from '../details.service'
@Component({
  selector: 'app-details-table',
  templateUrl: './details-table.component.html',
  styleUrls: ['./details-table.component.scss']
})
export class DetailsTableComponent implements OnInit {

  stateDetails
  constructor(public dialogRef: MatDialogRef<DetailsTableComponent>,public detailsService:DetailsService) { }

  ngOnInit() {
    this.stateDetails=this.detailsService.stateData;
    
  }

  onClose() {
    this.dialogRef.close();
  }

}
