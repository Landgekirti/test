import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryMoreComponent } from './summary-more.component';

describe('SummaryMoreComponent', () => {
  let component: SummaryMoreComponent;
  let fixture: ComponentFixture<SummaryMoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryMoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryMoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
