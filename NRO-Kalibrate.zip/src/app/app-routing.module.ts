import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { SegmentDetailComponent } from './components/segment-details/segment-details.component';
import { HeaderComponent } from './components/common/header/header.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { GrdFilterPipe1 } from './components/services/grd-filter.pipe';
import { LoginComponent } from './components/login/login.component'
import { MainKalibrateComponent } from './components/main-kalibrate/main-kalibrate.component';

const routes: Routes = [{ path: '', component: LoginComponent, pathMatch: 'full' },
{ path: 'app-main-kalibrate', component: MainKalibrateComponent },
{ path: 'app-segment-details', component: SegmentDetailComponent },
{ path: 'app-login', component: LoginComponent }];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
     providers: [
             {provide: LocationStrategy, useClass: HashLocationStrategy}
  ]
})
export class AppRoutingModule { }
