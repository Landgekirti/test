import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { RegionDataService } from '../region-data.service';
import { HttpCallsService } from '../../../services/http-calls.service';

@Component({
  selector: 'app-region-details',
  templateUrl: './region-details.component.html',
  styleUrls: ['./region-details.component.scss']
})
export class RegionDetailsComponent implements OnInit {

  loaderVal:boolean=true;
  constructor(public dialogRef: MatDialogRef<RegionDetailsComponent>,
    public httpService:HttpCallsService,
    public regionDataService:RegionDataService) {
      
     }

  ngOnInit() {
    this.getRegionDetails(this.regionDataService.RegionData);
  }

 regiondata
  getRegionDetails(data){
    
    this.loaderVal=true;
    this.httpService.getRegionDetails(data.RegionCode, data.StatusCode).subscribe((response)=>{
      
      this.loaderVal=false;
      this.regiondata=response;
      this.regiondata=this.regiondata.Table;
    },
    (error)=>{
      this.loaderVal=false;
        
    });
  }


  onClose() {
    this.dialogRef.close();
  }
}
