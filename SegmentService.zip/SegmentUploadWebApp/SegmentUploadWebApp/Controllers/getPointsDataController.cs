﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;

namespace SegmentUploadWebApp.Controllers
{
     [RoutePrefix("Api/getSegmentsData")] 
    public class getPointsDataController : ApiController
    {
        string ConnString = WebConfigurationManager.ConnectionStrings["KalibrateConn"].ConnectionString;

        [HttpPost]
        [Route("GetPointsDataBySegmentId")]
        public DataSet GetState([FromBody]InputValues Input)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetPointsbySegmentId", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@Segments", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@Segments"].Value = Input.segmentIdInput;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

        [HttpPost]
        [Route("CheckSegmentsState")]
        public DataSet CheckSegmentsState([FromBody]InputValues Input)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spCheckSegmentsState", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@segmentIds", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@segmentIds"].Value = Input.segmentIdInput;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@stateInput", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@stateInput"].Value = Input.stateInput;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }


    }
}

public class InputValues
{
    public string segmentIdInput { get; set; }

    public string stateInput { get; set; }

}