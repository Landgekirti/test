import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SummaryComponent } from './components/summary/summary.component';
import { ProposalComponent } from './components/proposal/proposal.component';
import { AnalyticsComponent } from './components/analytics/analytics.component';
import { MainMenuComponent } from './components/main-menu/main-menu.component';
import { PieChartComponent } from './components/common/pie-chart/pie-chart.component';
import { DonutChartComponent } from './components/common/donut-chart/donut-chart.component';
import { BarChartComponent } from './components/common/bar-chart/bar-chart.component';
import { NroTableComponent } from './components/common/nro-table/nro-table.component';
import { NgwWowModule } from 'ngx-wow';
import * as $ from 'jquery';
import { MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatButtonModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatSelectModule,
  MatTableModule,
  MatTabsModule,
  MatListModule,
  MatMenuModule,
  MatCheckboxModule,
  MatPaginatorModule,
  MatTooltipModule,
  
} from '@angular/material';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { StatusComponent } from './components/status/status.component';
import { DocketComponent } from './components/docket/docket.component';
import { CardviewComponent } from './components/cardview/cardview.component';
import { SummarybarComponent } from './components/summarybar/summarybar.component';
import { GridviewComponent } from './components/gridview/gridview.component';
import { SummaryMoreComponent } from './components/summary-more/summary-more.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { BreadcrumbComponent } from './components/common/breadcrumb/breadcrumb.component';
import { MapViewComponent } from './components/map-view/map-view.component';
import {RoundProgressModule} from 'angular-svg-round-progressbar';
import { CountUpModule  } from 'countup.js-angular2';
import { GrdFilterPipe } from './services/grd-filter.pipe';
import { FeildTableComponent } from './components/snapshot/feild-table/feild-table.component';
import { PopUpTableComponent } from './components/gridview/pop-up-table/pop-up-table.component';
import { QualitativeReportComponent } from './components/analytics/snapshot/qualitative-report/qualitative-report.component';
import { DetailsTableComponent } from './components/cardview/details-table/details-table.component';
import { RegionDetailsComponent } from './components/summary/region-details/region-details.component';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    SummaryComponent,
    ProposalComponent,
    AnalyticsComponent,
    MainMenuComponent,
    PieChartComponent,
    DonutChartComponent,
    BarChartComponent,
    NroTableComponent,
    HeaderComponent,
    FooterComponent,
    StatusComponent,
    DocketComponent,
    CardviewComponent,
    SummarybarComponent,
    GridviewComponent,
    SummaryMoreComponent,
    SidenavComponent,
    BreadcrumbComponent,
    MapViewComponent,
    GrdFilterPipe,
    FeildTableComponent,
    PopUpTableComponent,
    QualitativeReportComponent,
    DetailsTableComponent,
    RegionDetailsComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,    
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatTableModule,
    MatTabsModule,
    MatListModule,
    MatMenuModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatTooltipModule,
    NgwWowModule,
    RoundProgressModule,
    CountUpModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
