import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { LocalSevice } from './../../localservice.service'

@Component({  
  selector: 'app-proposal-Map',
  templateUrl: './proposal-Map.component.html',
  styleUrls: ['./proposal-Map.component.scss']
})
export class proposalMapComponent implements OnInit {

  allProposals;
  segmentDynamicInput;

  constructor(public dialogRef: MatDialogRef<proposalMapComponent>,
    public LocalSevice: LocalSevice) { }

  ngOnInit() {
    this.allProposals = this.LocalSevice.allProposalsData;
  }
  onClose() {
    this.dialogRef.close();
  }
}
