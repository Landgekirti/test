import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DetailsService {

  constructor() { }
  private _stateData: any[]=[];

  get stateData(): any[] {
    return this._stateData;
  }
  set stateData(obj: any[]) {
    this._stateData = obj;
  }
}
