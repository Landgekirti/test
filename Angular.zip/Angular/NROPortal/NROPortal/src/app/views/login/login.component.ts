import { Component, OnInit, OnDestroy} from '@angular/core';
import * as $ from 'jquery';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { SharedService } from '../../services/shared.service'
import { MessageService } from '../../services/message.service'
import { Router, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  status = false
  userName: any;
  welcomePage: boolean = false;
  loginPage: boolean = true;
  cookieUser: any
  formdata: any;
  hide;
  _user: {
    username: string
    password: string
  }
  public userResponse: any;
  welcome = new BehaviorSubject<boolean>(false);

  constructor(private localservice: SharedService,
    private MessageService: MessageService,
    private cookieService: CookieService,
    private router: Router) {
    this.formdata = new FormGroup({
      username: new FormControl("", Validators.compose([
        Validators.required
      ])),
      password: new FormControl("", this.passwordvalidation)
    });
  }

  ngOnInit(): void {  
    // sessionStorage.clear();
    this.hide=true; 
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('login-page');
    const menuToggle = $('.menuToggle');
    menuToggle.addClass('d-none');
    $(".labelUsername").css({"border":"none"});
    $("footer").addClass("footer-fix");
    $("i").css({"display":"none"}); 
    $(".iconDiv").css({"display":"none"}); 
    let user = this.localservice.getloginInfo();
    if (user !== undefined && user !== null) {
      this.userName = user["userName"].replace(".", " ");
    } 
  }


  passwordvalidation(formcontrol) {
    if (formcontrol.value.length < 5) {
      return { "password": true };
    }
  }

  onClickSubmit(data) {
    this.userName = data.username
    this.userName = this.userName.replace(".", " ");
    this._user = Object.assign({}, data);
    this.userlogin(this._user)
  }

  userlogin(data) {
    this.localservice.postLogin('https://ssoqa.ril.com', '/login', data, null).subscribe((response: any) => {
      this.userResponse = response.data;
      if (this.userResponse.status == true) {  
        this.localservice.setpIdInfo(this.userResponse)
        let loginInfo = { 'userName': data.username, 'status': true, 'fullName': this.userResponse.employeeName ? this.userResponse.employeeName : null, 'pid': this.userResponse.pid ? this.userResponse.pid : null, 'email': this.userResponse.emailID ? this.userResponse.emailID : null };
        this.localservice.setloginInfo(loginInfo);
        this.localservice.setUsernameInfo(loginInfo.fullName);
        this.localservice.setloggedIn(loginInfo.fullName);
        this.status = loginInfo.status
      }
      if (this.status == true) {
        this.router.navigate(['/home']);
      }
    }, (error) => {
      this.MessageService.openSnackBar("Access Denied!")
    });
  }


}
