import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {

  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    $('#flipButton1').on('click', function() {
      $('#box1').toggleClass('flipped');
    });
    $('#flipButton2').on('click', function() {
      $('#box2').toggleClass('flipped');
    });    
    $('#flipButton3').on('click', function() {
      $('#box3').toggleClass('flipped');
    });
    $('#flipButton4').on('click', function() {
      $('#box4').toggleClass('flipped');
    });
    $(function(){
          function equalHeight(){
              var heightArray = $(".common-flip").map( function(){
                  return  $(this).height();
              }).get();
              
              var maxHeight = Math.max.apply( Math, heightArray);
                  $(".common-flip").height(maxHeight);
              }
          equalHeight();
    });        
  }
 
     
}
