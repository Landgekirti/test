import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import { SharedService } from '../../../services/shared.service'
import { stringify } from 'querystring';
import { Router, NavigationEnd } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor(private SharedService:SharedService,
    private cookieService: CookieService,
    private router: Router) { }
  selected = 'Platform';
  username;UserId;
  loggedInInfo;
  imgUrl;cookieUser
  UserRole;user; UserCode
  sidenavToggle() {
    console.log('clicked');
    $('body').toggleClass('nav-close');
  }

  ngOnInit() {
    this.cookieUser = this.cookieService.get('USER');
    this.cookieUser = JSON.parse(this.cookieUser);
    this.username = this.cookieUser.fullname.replace("+", " ");;
    // console.log("UserName",this.username)  
    this.user = JSON.parse(sessionStorage.loginInfo);
    console.log("user",this.user.userName)  
    this.UserCode = this.user.userName
     console.log("UserCode",this.UserCode)  
    this.SharedService.GetUserRole(this.UserCode).subscribe(data=>{
      this.UserRole = data.Table[0].Role_Code 
      console.log("UserRole",this.UserRole)    
    });

    // this.SharedService.GetUserIdbyDomain(this.user.userName).subscribe(data=>{
    //   this.UserId = data.Table[0]
    //   // console.log("UserId",this.UserId)
    // });

    this.loggedInInfo = sessionStorage.loginInfo
    if (this.loggedInInfo) {
      if (this.loggedInInfo.pid != null && this.loggedInInfo.pid != '') {
        // this.imgUrl = `http://mobcontent.ril.com/picture/${this.loggedInInfo.pid.substring(1)}.jpg`;
      }
    }

    (function (window, document, undefined) {
      'use strict';

      // Initialize the media query
      const mediaQuery = window.matchMedia('(max-width: 768px)');

      // Add a listen event
      mediaQuery.addListener(doSomething);

      // Function to do something with the media query
      function doSomething(mediaQuery: any) {
        if (mediaQuery.matches) {
          $("body").addClass("nav-close");
        } else {
          //
          $("body").removeClass("nav-close");
        }
      }
      // On load
      doSomething(mediaQuery);

      // Modernizr
      // window.addEventListener('resize', function() {
      //  if (Modernizr.mq('(min-width: 560px)')) {
      //    document.body.style.backgroundColor = 'CornflowerBlue';
      //  } else {
      //    document.body.style.backgroundColor = 'FireBrick';
      //  }
      // }, false);

    })(window, document);
  }

  onClickLogout(){
    this.router.navigate(['/login']);
    this.SharedService.setloggedIn("");
    // sessionStorage.clear();
  }

}
