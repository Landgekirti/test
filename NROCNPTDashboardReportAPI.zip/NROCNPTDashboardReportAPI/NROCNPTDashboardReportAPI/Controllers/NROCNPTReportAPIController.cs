﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NROCNPTDashboardReportAPI.Controllers
{

    [NROCNPTCORSPolicy]
    public class NROCNPTReportAPIController : ApiController
    {
        string ConnString = WebConfigurationManager.ConnectionStrings["NROCNPTConn"].ConnectionString;

        // GET api/nrocnptreportapi
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/nrocnptreportapi/5
        public string Get(int id)
        {
            return "value";
        }

        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetRegionSummary")]
        public DataSet GetRegionSummary([FromBody]Filters RegionFilter)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportRegionWiseProposalSummary", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@RegionCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@RegionCode"].Value = RegionFilter.RegionCode;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e) { throw e; }
        }

        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetStateSummary")]
        public DataSet GetStateSummary([FromBody]Filters StateFilter)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportStateSummary", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@RegionCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@RegionCode"].Value = StateFilter.RegionCode;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetIndiaSummary")]
        public DataSet GetIndiaSummary()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportIndiaProposalSummary", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetUserDetails")]
        public DataSet GetUserDetails([FromBody]User UserCode)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetUserRelatedDetails", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@UserCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@UserCode"].Value = UserCode.UserCode;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetStateWiseProposalCountWithFilters")]

        public DataSet GetStateWiseProposalCountWithFilters([FromBody]Filters Filters )
        {

            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spNROCNPTDashReportStateSummaryFilters", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@RegionCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@RegionCode"].Value =Filters.RegionCode ;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@StateFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@StateFilter"].Value = Filters.StateFilter;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@DistrictFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@DistrictFilter"].Value = Filters.DistrictFilter;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@RoadClasFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@RoadClasFilter"].Value = Filters.RoadClasFilter;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@CategoryFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@CategoryFilter"].Value = Filters.CategoryFilter;
                    
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@SubCategoryFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@SubCategoryFilter"].Value = Filters.SubCategoryFilter;

                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@VolCatTAFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@VolCatTAFilter"].Value = Filters.VolCatTAFilter;

                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@VolCatPVFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@VolCatPVFilter"].Value = Filters.VolCatPVFilter;

                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@MEFilter", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@MEFilter"].Value = Filters.MEFilter;

                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        
        }

        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetDropDowns")]
        public DataSet GetDropDowns(string dropdownType)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetNROCNPTDashReportMasterDropdowns", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@DropdownType", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@DropdownType"].Value = dropdownType;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        [HttpPost]
        [Route("api/NROCNPTReportAPI/GetRegionAndStatusWiseProposals")]
        public DataSet GetRegionAndStatusWiseProposals(string RegionCode, string StatusCode)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportStatusWiseSummary", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@RegionCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@RegionCode"].Value = RegionCode;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@StatusCode", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@StatusCode"].Value = StatusCode;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [HttpGet]
        [Route("api/NROCNPTReportAPI/GenerateExcelReportData")]
        public DataTable GenerateExcelReportData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportDataForExcelExport", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return dt;
                }
            }
            catch (Exception e) { throw e; }
        }


        [HttpGet]
        [Route("api/NROCNPTReportAPI/GenerateExcelReportDataNRO")]
        public DataTable GenerateExcelReportDataNRO()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportDataForExcelExportNRO", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return dt;
                }
            }
            catch (Exception e) { throw e; }
        }


        [HttpGet]
        [Route("api/NROCNPTReportAPI/GenerateExcelReportDataERO")]
        public DataTable GenerateExcelReportDataERO()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportDataForExcelExportERO", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return dt;
                }
            }
            catch (Exception e) { throw e; }
        }

        // POST api/nrocnptreportapi
        public void Post()
        {

        }

        // PUT api/nrocnptreportapi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/nrocnptreportapi/5
        public void Delete(int id)
        {
        }
    }
}

public class Filters
{
    public string RegionCode { get; set; }

    public string StateFilter { get; set; }
    public string DistrictFilter  { get; set; }
    public string RoadClasFilter { get; set; }
    public string CategoryFilter { get; set; }
    public string SubCategoryFilter { get; set; }
    public string VolCatTAFilter { get; set; }
    public string VolCatPVFilter { get; set; }
    public string MEFilter { get; set; }

}

public class User
{
    public string UserCode { get; set; }
}


public class NROCNPTCORSPolicy : Attribute, ICorsPolicyProvider
{
    private CorsPolicy _policy;

    public NROCNPTCORSPolicy()
    {
        // Create a CORS policy. 
        _policy = new CorsPolicy
        {
            AllowAnyMethod = true,
            AllowAnyHeader = true,
            AllowAnyOrigin = true,
            
        };

        // Add allowed origins. 
        var origins = Convert.ToString(ConfigurationManager.AppSettings["CORSOrigin"]);
        _policy.Origins.Add(origins);

    }

    public Task<CorsPolicy> GetCorsPolicyAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        return Task.FromResult(_policy);
    }
}