// import { Component, OnInit,ChangeDetectorRef, SimpleChanges } from '@angular/core';
// import { Router } from '@angular/router';
// import { NroTableModel } from '../../common/nro-table/nro-table.model';
// import { HttpCallsService } from "../../../services/http-calls.service";
// import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
// import { Observable } from 'rxjs';
// import { ElementRef } from '@angular/core';
// import { ViewChild } from '@angular/core';
// import { GlobalService } from '../../../services/global.service';
// import * as XLSX from 'xlsx';

// @Component({
//   selector: 'app-feild-table',
//   templateUrl: './feild-table.component.html',
//   styleUrls: ['./feild-table.component.scss']
// })

// export class FeildTableComponent implements OnInit {

//   @ViewChild('TABLE') table: ElementRef; 
//   _oRilTableModel: NroTableModel = null;
//   oResponse: any;
//   oListData: any[];
//   showChild:boolean=false;
//   _oChangeTrigger:number=1;
//   stateData: any;
//   deleteIds = Array<{recordIds: number}>();
//     delObj
//   delAction:any;
  

//   displayedColumns = ['StateCode', 'TotalProposalCount','CompletedCount','SubmittedCount','QueryCount','RejectedCount','AvgTASizeCat','AvgPotentialVolCat'];
  
//  columns = [
//     { columnDef: 'StateCode', header: 'State',showTooltip:'true', cell: (element: any) => `${element.StateCode}` },
//     { columnDef: 'TotalProposalCount', header: 'Total Proposal', showTooltip:'true',cell: (element: any) => `${element.TotalProposalCount}` },
//     { columnDef: 'CompletedCount', header: 'RO Code Generated', showTooltip:'true',cell: (element: any) => `${element.CompletedCount}` },
//     { columnDef: 'SubmittedCount', header: 'Proposals Pending', showTooltip:'true',cell: (element: any) => `${element.SubmittedCount}` },
//     { columnDef: 'QueryCount', header: 'Query Raised', showTooltip:'true',cell: (element: any) => `${element.QueryCount}` },
//     { columnDef: 'RejectedCount', header: 'Proposals Rejected', showTooltip:'true',cell: (element: any) => `${element.RejectedCount}` },
//     { columnDef: 'AvgTASizeCat', header: 'Average TA Volume', showTooltip:'true',cell: (element: any) => `${element.AvgTASizeCat}` },
//     { columnDef: 'AvgPotentialVolCat', header: 'Average Potential Volume', showTooltip:'true',cell: (element: any) => `${element.AvgPotentialVolCat}` },];

//   constructor(
//     private router: Router,
//     private httpService: HttpCallsService,
//     private MatDialog: MatDialog,
//     private changeDetectorRefs: ChangeDetectorRef,
//     private globalService : GlobalService
//   ) { }

//   ngOnInit() {
//     this.tableConstructor();
//   }

//   tableConstructor(){
//      this._oRilTableModel = new NroTableModel();    
//     this.serCall();       
//     this._oRilTableModel.displayedColumns = this.displayedColumns;
//     this._oRilTableModel.columns = this.columns;
//   this._oRilTableModel.pageSizeOptions = [1, 5, 10, 25, 100];
//     this.changeDetectorRefs.detectChanges();
//   }

 


//   clickAction() {
    
//   }  

  
  

//   errMessage:any;
//   reqObj

 
//   serCall() {

//     this.reqObj={
//       RegionCode: "North"
//     }
//     this.httpService.getStateSummary(this.reqObj).subscribe((response) => {
//       this.stateData=response;

      
//      this.showChild =true;
//      this._oRilTableModel.dataSource = this.stateData.Table;
     
//      this._oChangeTrigger ++;
//      }, (error) => {
           
//            this.showChild =true;
//          }
//      );
//   }   
  
//   onDownload(item) {
//     let oDownloadList = [];
//     let todaysDate = new Date();
//     let month=todaysDate.getMonth()+1;
//     let fileName ="Donee"+todaysDate.getDate()+"_"+month+"_"+todaysDate.getFullYear()+'.xlsx';

//     try {
//       if (this._oRilTableModel.dataSource.length > 0) {
//         this._oRilTableModel.dataSource.forEach(element => {
//           oDownloadList.push({
//             'vendorName': element.vendorName,
//             'companyMaster' : element.companyMaster.companyName,
//             'pan' : element.pan,
//             'categoryCode' : element.categoryCode,
//             'rateCode'  : element.categoryCode,
//             'validatedOnDeptWebSite' : element.validatedOnDeptWebSite,
//           })
//         });
//         const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(oDownloadList);
//         ws['A1'].v = "Vendor Name";
//         ws['B1'].v = "Company";
//         ws['C1'].v = "PAN";
//         ws['D1'].v = "Category";
//         ws['E1'].v = "Rate";
//         ws['F1'].v = "Validated On Dept. WebSite";
//         ws['G1'].v = "Applicable From";
//         ws['H1'].v = "Applicable To";
  
  
//         const wb: XLSX.WorkBook = XLSX.utils.book_new();
//         XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  
//         /* save to file */
//         XLSX.writeFile(wb, fileName);
//       }
//       else {
        
//       }
//     } catch (error) {

//     }
//   }
// }
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { FormControl } from '@angular/forms';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { position: 1, name: 'Hydrogen', weight: 2, symbol: 'H' },
  { position: 2, name: 'Helium', weight: 3, symbol: 'He' },
  { position: 3, name: 'Lithium', weight: 4, symbol: 'Li' },
  { position: 4, name: 'Beryllium', weight: 6, symbol: 'Be' },
  { position: 5, name: 'Boron', weight: 5, symbol: 'B' },
  { position: 6, name: 'Carbon', weight: 8, symbol: 'C' },
  { position: 7, name: 'Nitrogen', weight: 10, symbol: 'N' },
  { position: 8, name: 'Oxygen', weight: 9, symbol: 'O' },
  { position: 9, name: 'Fluorine', weight: 19, symbol: 'F' },
  { position: 10, name: 'Neon', weight: 20, symbol: 'Ne' },
];

/**
 * @title Table with filtering
 */
@Component({
    selector: 'app-feild-table',
    templateUrl: './feild-table.component.html',
    styleUrls: ['./feild-table.component.scss']
  })
export class FeildTableComponent implements OnInit {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  positionFilter = new FormControl();
  nameFilter = new FormControl();
  weightFilter = new FormControl();
  globalFilter = '';

  filteredValues = {
    position: '', name: '', weight: '',
    symbol: ''
  };
  ngOnInit() {

    this.positionFilter.valueChanges.subscribe((positionFilterValue) => {
      this.filteredValues['position'] = positionFilterValue;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      
    });

    this.nameFilter.valueChanges.subscribe((nameFilterValue) => {
      this.filteredValues['name'] = nameFilterValue;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      
    });

    this.weightFilter.valueChanges.subscribe((weightFilterValue) => {
      
      this.filteredValues['weight'] = weightFilterValue;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      
    });

    this.dataSource.filterPredicate = this.customFilterPredicate();

  }

  applyFilter(filter) {
    this.globalFilter = filter;
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }

  // numFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  //   this.dataSource.filterPredicate = (data: any, fitlerString: string) => {

  //       return data.position == filterValue;
  //   };
  //   this.dataSource.filter = filterValue;
  // }

  customFilterPredicate() {
    const myFilterPredicate = (data: PeriodicElement, filter: string): boolean => {
      var globalMatch = !this.globalFilter;

      if (this.globalFilter) {
        // search all text fields
        globalMatch = data.name.toString().trim().toLowerCase().indexOf(this.globalFilter.toLowerCase()) !== -1;
      }

      if (!globalMatch) {
        return;
      }

      let searchString = JSON.parse(filter);
      return data.position.toString().trim().indexOf(searchString.position) !== -1 &&
      data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1 &&
      data.weight.toString().trim().toLowerCase().indexOf(searchString.weight) !== -1;
    }
    return myFilterPredicate;
  }
}