import { Component, OnInit } from "@angular/core";
import * as $ from "jquery";
import "owl.carousel";
import { environment } from 'src/environments/environment'
import { SharedService } from '../../services/shared.service'

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  //mySlideImages = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => `https://picsum.photos/640/480?image=${i}`);
  mySlideOptions = { items: 4, dots: true, nav: true, margin: 15 };
  NROPortal;Kalibrate;ExistingRO;Dashboard;user;UserCode;UserRole;
  constructor(private SharedService: SharedService) {
    $("footer").removeClass("footer-fix");
    this.NROPortal  = environment.NROPortal,
    this.Kalibrate = environment.Kalibrate,
    this.ExistingRO = environment.ExistingRO,
    this.Dashboard = environment.Dashboard
  }

  ngOnInit() {
    // $("footer").removeClass("footer-fix");
    $(function(){
          function equalHeight(){
              var heightArray = $(".box a").map( function(){
                  return  $(this).height();
              }).get();
              var maxHeight = Math.max.apply( Math, heightArray);
                  $(".box a").height(maxHeight);    
              }
          equalHeight();
    });

    this.user = JSON.parse(sessionStorage.loginInfo);
    this.UserCode = this.user.userName
    console.log("UserName",this.user.userName)  
    this.SharedService.GetUserRole(this.UserCode).subscribe(data=>{
      this.UserRole = data.Table[0].Role_Code 
      console.log("UserRole in HOMEpage",this.UserRole)  
    });
  }
  
  OnclickNROPortal(){
    window.open(this.NROPortal,'_blank');
  }

  OnclickKalibrate(){
    window.open(this.Kalibrate,'_blank');
  }  
  
  OnclickExistingRO(){
    window.open(this.ExistingRO,'_blank');
  }

  OnclickDashboard(){
    window.open(this.Dashboard,'_blank');
  }
}  
