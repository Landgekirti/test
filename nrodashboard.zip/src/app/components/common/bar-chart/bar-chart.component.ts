import { Component, OnInit, Input } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import  am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { HttpCallsService } from '../../../services/http-calls.service';

/* Chart code */
// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {
  @Input() oInputNav
  constructor(public httpService:HttpCallsService) { 
    
  }

  ngOnInit() {
    this.getRegionData();
  }

  logoDisplay(){
    var logo1 = document.getElementsByTagName('title')[2].parentElement;
    
    logo1.style.display = "none";
  }

  createCharts

  reportDetails
  obj
getRegionData(){
  this.obj={
    "RegionCode": "North"
  }
    this.httpService.getRegionSummary(this.obj).subscribe((response) => {
      
      this.reportDetails=response;
      this.reportDetails=this.reportDetails.Table;
      this.generatecharts(this.reportDetails);

    }, (error) => {
        
    }
    );
  }
  generatecharts(data){
      // Create chart instance

let chart = am4core.create("chartdivbar", am4charts.XYChart);


// Add data
chart.data = data;

chart.width=350;
// Create axes
let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "RegionName";
//categoryAxis.numberFormatter.numberFormat = "#";
categoryAxis.renderer.inversed = true;
categoryAxis.renderer.grid.template.location = 0.5;
categoryAxis.renderer.cellStartLocation = 0.1;
categoryAxis.renderer.cellEndLocation = 0.5;
categoryAxis.renderer.maxLabelPosition=0.8;
categoryAxis.startLocation=0;
categoryAxis.endLocation=1.4;
categoryAxis.renderer.minGridDistance = 0.4;

let  valueAxis = chart.yAxes.push(new am4charts.ValueAxis()); 
valueAxis.renderer.opposite = true;

// Create series
function createSeries(field, name) {
  let series = chart.series.push(new am4charts.ColumnSeries());
  series.dataFields.valueY = field;
  series.dataFields.categoryX = "RegionName";
  series.name = name;
  series.columns.template.tooltipText = "{name}: [bold]{valueY}[/]";
  series.columns.template.height = am4core.percent(100);
  series.sequencedInterpolation = true;


  let valueLabel = series.bullets.push(new am4charts.LabelBullet());
  valueLabel.label.text = "{valueX}";
  valueLabel.label.horizontalCenter = "left";
  valueLabel.label.dx = 5;
  valueLabel.label.hideOversized = false;
  valueLabel.label.truncate = false;

  let categoryLabel = series.bullets.push(new am4charts.LabelBullet());
  categoryLabel.label.text = "";
  categoryLabel.label.horizontalCenter = "right";
  categoryLabel.label.dx = -5;
  categoryLabel.label.fill = am4core.color("#000000");
  categoryLabel.label.hideOversized = false;
  categoryLabel.label.truncate = false;
}

createSeries("TotalProposalCount", "Total Proposal");
createSeries("SubmittedCount", "Submitted");
createSeries("RejectedCount", "Rejected")
//createSeries("CompletedCount", "Completed");

createSeries("QueryCount", "Query");


chart.legend = new am4charts.Legend();

//chart.legend.useDefaultMarker = true;
let marker = chart.legend.markers.template.children.getIndex(0);
marker.width = 10;
marker.height = 10;
chart.legend
//marker.cornerRadius(12, 12, 12, 12);
marker.strokeWidth = 1;
marker.strokeOpacity = 1;
marker.stroke = am4core.color("#ccc");
this.logoDisplay();
  }

}