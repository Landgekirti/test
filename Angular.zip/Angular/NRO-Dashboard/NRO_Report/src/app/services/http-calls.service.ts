import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Headers,Http, RequestOptions, Response, URLSearchParams } from "@angular/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HttpCallsService {
  //JIOProd
  // serverIp='http://10.26.38.19/NROCNPTDashboardService/api/NROCNPTReportAPI';
  // excelIp='http://10.26.38.19/NROCNPTDashboardService/api/NROCNPTReportAPI/GenerateExcelReportData';
  
  //RILProd
  serverIp='https://wfservices.ril.com/NROPortal/NROCNPTDashboardService/api/NROCNPTReportAPI';
  excelIp='https://wfservices.ril.com/NROPortal/NROCNPTDashboardService/api/NROCNPTReportAPI/GenerateExcelReportData';

  //serverIp='http://10.131.133.21/NROCNPTReportService/api/NROCNPTReportAPI';
  // serverIp='https://bpmrepservices.jio.com/NROCNPTReportservice/api/NROCNPTReportAPI';
  // excelIp='https://bpmrepservices.jio.com/NROCNPTReportservice/api/NROCNPTReportAPI/GenerateExcelReportData';
  // serverIp='https://bpmservices.jio.com/NROCNPTReportService/api/NROCNPTReportAPI';
  // excelIp='https://bpmservices.jio.com/NROCNPTReportService/api/NROCNPTReportAPI/GenerateExcelReportData';
  
  
  constructor(private http: HttpClient) { }

  getRegionSummary(data) {
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetRegionSummary',{body:data,headers:headers});
   }

   getStateSummary(data) {
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetStateSummary',{body:data,headers:headers});
   }

   getIndiaSummary(){
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetIndiaSummary',{body:'',headers:headers});
   }

   getFilterDataquant(data){
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetStateWiseProposalCountWithFilters',{body:data,headers:headers});
   }

   getFilterDropdown(data){
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetDropDowns',{body:data,headers:headers});
   }
   getRegionDetails(region,status){
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('POST',this.serverIp+'/GetRegionAndStatusWiseProposals?RegionCode='+region+'&StatusCode='+status,{body:'',headers:headers});
   }

   getExcel(){
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.request('GET',this.excelIp,{headers:headers});
   }
}
