﻿using ClosedXML.Excel;
using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;

namespace NROCNPTDashboardReportAPI.Controllers
{
    [NROCNPTCORSPolicy2]
    public class ExcelReportGenController : ApiController
    {
        string ConnString = WebConfigurationManager.ConnectionStrings["NROCNPTConn"].ConnectionString;


        [HttpGet]
        [Route("api/ExcelReportGenController/GenerateExcelReport")]
        public void GenerateExcelReport()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetCNPTDashReportDataForExcelExport", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    ExporttoExcel(ds);
                }
            }
            catch (Exception e) { throw e; }
        }

        [HttpPost]
        [Route("api/ExcelReportGenController/GenerateAndDownloadExcel")]
        public void ExporttoExcel(DataSet TableInput)
        {
            string AppLocation = "";
            AppLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            AppLocation = AppLocation.Replace("file:\\", "");
            string date = DateTime.Now.ToShortDateString();
            date = date.Replace("/", "_");
            string filepath = AppLocation + "\\ExcelFiles\\" + "NROCNPT_Report_" + date + ".xlsx";
            string FileName = "NROCNPT_Report_" + date + ".xlsx";

            using (XLWorkbook wb = new XLWorkbook())
            {
                for (int i = 0; i < TableInput.Tables.Count; i++)
                {
                    //for (int j = 0; j < TableInput.Columns.Count; j++)
                    //{
                    TableInput.Tables[i].TableName = "NROCNPT-Report";
                    wb.Worksheets.Add(TableInput.Tables[i], TableInput.Tables[i].TableName);

                    //}
                }
                wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                wb.Style.Font.Bold = true;
                // Prepare the response
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.Buffer = true;
                HttpContext.Current.Response.Charset = "";
                HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                //Provide you file name here
                HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" + FileName);

                // Flush the workbook to the Response.OutputStream
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    wb.SaveAs(memoryStream);
                    memoryStream.WriteTo(HttpContext.Current.Response.OutputStream);
                    HttpContext.Current.Response.Flush();
                    //memoryStream.Close();

                    HttpContext.Current.Response.End();

                }

            }
        }

    }


}

public class NROCNPTCORSPolicy2 : Attribute, ICorsPolicyProvider
{
    private CorsPolicy _policy2;

    public NROCNPTCORSPolicy2()
    {
        // Create a CORS policy. 
        _policy2 = new CorsPolicy
        {
            AllowAnyMethod = true,
            AllowAnyHeader = true,
            AllowAnyOrigin = true,

        };

        // Add allowed origins. 
        var origins = Convert.ToString(ConfigurationManager.AppSettings["CORSOrigin"]);
        _policy2.Origins.Add(origins);

    }

    public Task<CorsPolicy> GetCorsPolicyAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        return Task.FromResult(_policy2);
    }
}

