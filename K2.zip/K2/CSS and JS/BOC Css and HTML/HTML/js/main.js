$(document).ready(function() {
    $('[data-toggle=offcanvas]').click(function() {
        $('.row-offcanvas').toggleClass('active');
    });
});

$(document).ready(function(){
	$(".btn1").click(function(){
	    $(".tab1").show();
	    $(".tab2").hide();
	    $(".tab3").hide();
	    $(".btn1").addClass('active');                    
	    $(".btn2").removeClass('active');
	    $(".btn3").removeClass('active');
	});
	$(".btn2").click(function(){
	    $(".tab2").show();
	    $(".tab1").hide();
	    $(".tab3").hide();
	    $(".btn1").removeClass('active');
	    $(".btn3").removeClass('active');
	    $(".btn2").addClass('active');
	});   
	$(".btn3").click(function(){
	   $(".tab3").show();
	   $(".tab1").hide();
	   $(".tab2").hide();
	   $(".btn1").removeClass('active');
	   $(".btn2").removeClass('active');
	   $(".btn3").addClass('active');
	});  
});

$(function() {
  $('input[name="daterange"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});

 // $(this).toggleClass("");    
 // $(this).parent().find(".").toggleClass("");   

$(document).ready(function(){
	$(".m-tabBtnL").click(function(){
	    $(".list1").show();
	    $(".list2").hide();
	    $(".m-tabBtnL").addClass('m-activeBtn');                    
	    $(".m-tabBtnR").removeClass('m-activeBtn');
	});
	$(".m-tabBtnR").click(function(){
	    $(".list1").hide();
	    $(".list2").show();
	    $(".m-tabBtnR").addClass('m-activeBtn');                    
	    $(".m-tabBtnL").removeClass('m-activeBtn');
	});  
});

$(function(){
    function equalHeight(){ 
        var heightArray = $(".sameHeight").map( function(){
            return  $(this).height();
        }).get(); 
        var maxHeight = Math.max.apply( Math, heightArray);
            $(".sameHeight").height(maxHeight);
        } 
    equalHeight();
});
      