import { Component, OnInit, NgZone, Output, EventEmitter } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4maps from "@amcharts/amcharts4/maps";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import indiaLow from "@amcharts/amcharts4-geodata/indiaLow";

am4core.useTheme(am4themes_animated);
@Component({
  selector: 'app-map-view',
  templateUrl: './map-view.component.html',
  styleUrls: ['./map-view.component.scss']
})
export class MapViewComponent implements OnInit {
  @Output() ongetData = new EventEmitter<object>();
  @Output() ongetData1 = new EventEmitter<object>();
  private chart: am4maps.MapChart;
  private polygonData;
  private zone: NgZone
  constructor() { }

  ngOnInit() {
  }

  regionDetals
  ngAfterViewInit() {

    // Create map instance
    var chart = am4core.create("chartdiv", am4maps.MapChart);

    /* Set map definition */
    chart.geodata = indiaLow;

    /* Set projection */
    chart.projection = new am4maps.projections.Mercator();
    chart.chartContainer.wheelable = false;

    /* Northern Europe */
    var series1 = chart.series.push(new am4maps.MapPolygonSeries());
    series1.name = "North";
    series1.useGeodata = true;
    series1.include = ["IN-CH", "IN-DL", "IN-HP", "IN-HR", "IN-JK", "IN-PB", "IN-RJ", "IN-UP", "IN-UT"];
    series1.mapPolygons.template.tooltipText = "{series.name}: [bold]{name}[/]";
    series1.events.on("over", over);
    series1.events.on("out", out);
    series1.mapPolygons.template.fill = am4core.color("#81968F");
    series1.fill = am4core.color("#05324B");
    var hover = series1.mapPolygons.template.states.create("highlight");
    hover.properties.fill = am4core.color("#05324B");
    

    /* Central Europe */
    var series2 = chart.series.push(new am4maps.MapPolygonSeries());
    series2.name = "South";
    series2.useGeodata = true;
    series2.include = ["IN-AP", "IN-KA", "IN-KL", "IN-PY", "IN-TG", "IN-TN"];
    series2.mapPolygons.template.tooltipText = "{series.name}: [bold]{name}[/]";
    series2.events.on("over", over);
    series2.events.on("out", out);
    series2.mapPolygons.template.fill = am4core.color("#81968F");
    series2.fill = am4core.color("#B80C09");
    var hover = series2.mapPolygons.template.states.create("highlight");
    hover.properties.fill = am4core.color("#B80C09");

    /* Eastern Europe */
    var series3 = chart.series.push(new am4maps.MapPolygonSeries());
    series3.name = "East";
    series3.useGeodata = true;
    series3.include = ["IN-BR", "IN-JH", "IN-OR", "IN-WB", "IN-SK","IN-AR", "IN-AS", "IN-ML", "IN-MN", "IN-MZ", "IN-NL", "IN-TR"];
    series3.mapPolygons.template.tooltipText = "{series.name}: [bold]{name}[/]";
    series3.events.on("over", over);
    series3.events.on("out", out);
    series3.mapPolygons.template.fill = am4core.color("#81968F");
    series3.fill = am4core.color("#FF1654");
    var hover = series3.mapPolygons.template.states.create("highlight");
    hover.properties.fill = am4core.color("#FF1654");

    /* Southeast Europe */
    var series4 = chart.series.push(new am4maps.MapPolygonSeries());
    series4.name = "West";
    series4.useGeodata = true;
    series4.include = ["IN-MH", "IN-GA", "IN-GJ", "IN-MP","IN-CT"];
    series4.mapPolygons.template.tooltipText = "{series.name}: [bold]{name}[/]";
    series4.events.on("over", over);
    series4.events.on("out", out);
    series4.mapPolygons.template.fill = am4core.color("#81968F");
    series4.fill = am4core.color("#5F0A87");
    var hover = series4.mapPolygons.template.states.create("highlight");
    hover.properties.fill = am4core.color("#5F0A87");

    /* Western Europe */
    // var series5 = chart.series.push(new am4maps.MapPolygonSeries());
    // series5.name = "Northeast";
    // series5.useGeodata = true;
    // series5.include = ["IN-AR", "IN-AS", "IN-ML", "IN-MN", "IN-MZ", "IN-NL", "IN-TR"];
    // series5.mapPolygons.template.tooltipText = "{series.name}: [bold]{name}[/]";
    // series5.events.on("over", over);
    // series5.events.on("out", out);
    // series5.mapPolygons.template.fill = am4core.color("#81968F");
    // series5.fill = am4core.color("#0CF574");
    // var hover = series5.mapPolygons.template.states.create("highlight");
    // hover.properties.fill = am4core.color("#0CF574");

    /*legend*/
    chart.legend = new am4maps.Legend();
    chart.legend.position = "right";
   // chart.legend.align = "right";
    chart.legend.valign = "bottom";
    chart.legend.itemContainers.template.togglable = false;

    // let labelSeries = chart.series.push(new am4maps.MapImageSeries());
    //   let labelTemplate = labelSeries.mapImages.template.createChild(am4core.Label);
    //   labelTemplate.horizontalCenter = "middle";
    //   labelTemplate.verticalCenter = "middle";
    //   labelTemplate.fontSize = 13;
    //   labelTemplate.nonScaling = false;
    //   labelTemplate.interactionsEnabled = false;
    //   labelTemplate.fill = am4core.color("#FFFFFF");
    //   series1.events.on("validated", function () {		
    //     series1.mapPolygons.each(function (polygon) {		
    //       let label = labelSeries.mapImages.create();		
    //       let state = polygon.dataItem.dataContext.id.split("-").pop();		
    //       label.latitude = polygon.visualLatitude;		
    //       label.longitude = polygon.visualLongitude;		
    //       // label.children.getIndex(0).text = polygon.dataItem.dataContext.name;		
    //       label.children.getIndex(0).text = state;		
    //     });		  
    //   });
    //   series2.events.on("validated", function () {		
    //     series2.mapPolygons.each(function (polygon) {		
    //       let label = labelSeries.mapImages.create();		
    //       let state = polygon.dataItem.dataContext.id.split("-").pop();		
    //       label.latitude = polygon.visualLatitude;		
    //       label.longitude = polygon.visualLongitude;		
    //       // label.children.getIndex(0).text = polygon.dataItem.dataContext.name;		
    //       label.children.getIndex(0).text = state;		
    //     });		  
    //   });
    //   series3.events.on("validated", function () {		
    //     series3.mapPolygons.each(function (polygon) {		
    //       let label = labelSeries.mapImages.create();		
    //       let state = polygon.dataItem.dataContext.id.split("-").pop();		
    //       label.latitude = polygon.visualLatitude;		
    //       label.longitude = polygon.visualLongitude;		
    //       // label.children.getIndex(0).text = polygon.dataItem.dataContext.name;		
    //       label.children.getIndex(0).text = state;		
    //     });		  
    //   });
    //   series4.events.on("validated", function () {		
    //     series4.mapPolygons.each(function (polygon) {		
    //       let label = labelSeries.mapImages.create();		
    //       let state = polygon.dataItem.dataContext.id.split("-").pop();		
    //       label.latitude = polygon.visualLatitude;		
    //       label.longitude = polygon.visualLongitude;		
    //       // label.children.getIndex(0).text = polygon.dataItem.dataContext.name;		
    //       label.children.getIndex(0).text = state;		
    //     });		  
    //   });

    //   series5.events.on("validated", function () {		
    //     series5.mapPolygons.each(function (polygon) {		
    //       let label = labelSeries.mapImages.create();		
    //       let state = polygon.dataItem.dataContext.id.split("-").pop();		
    //       label.latitude = polygon.visualLatitude;		
    //       label.longitude = polygon.visualLongitude;		
    //       // label.children.getIndex(0).text = polygon.dataItem.dataContext.name;		
    //       label.children.getIndex(0).text = state;		
    //     });		  
    //   });

    var self = this; 
    var region;
   var polygonTemplate = series1.mapPolygons.template;
   polygonTemplate.events.on("hit", function(ev) {
    
    region="North";
      
    self.getRegion(region);
   });

   var polygonTemplate1 = series2.mapPolygons.template;
   polygonTemplate1.events.on("hit", function(ev) {
     
    region="South";
      
    self.getRegion(region);
    });
    var polygonTemplate2 = series3.mapPolygons.template;
    polygonTemplate2.events.on("hit", function(ev) {
     
    region="East";
      
    self.getRegion(region);
    });
    var polygonTemplate3 = series4.mapPolygons.template;
    polygonTemplate3.events.on("hit", function(ev) {
     
    region="West";
      
    self.getRegion(region);
    });

    series1.mapPolygons.template.events.on("over",function(ev) {
         
       
      region="North";
        
      self.getRegion1(region);
    });

    series2.mapPolygons.template.events.on("over",function(ev) {
         
       
      region="South";
        
      self.getRegion1(region);
    });

    series3.mapPolygons.template.events.on("over",function(ev) {
         
       
      region="East";
        
      self.getRegion1(region);
    });

    series4.mapPolygons.template.events.on("over",function(ev) {
         
       
      region="West";
        
      self.getRegion1(region);
    });

    // series5.mapPolygons.template.events.on("over",function(ev) {
    //      
    //    
    //   region="East";
    //     
    //   self.getRegion1(region);
    // });

    function over(ev) {
      ev.target.mapPolygons.each(function (polygon) {
        polygon.setState("highlight");
      });
    }

    function out(ev) {
      ev.target.mapPolygons.each(function (polygon) {
        polygon.setState("default");
      });
    }

    var logo = document.getElementsByTagName('title')[1].parentElement;
        logo.style.display = "none";
     
    
  }
  

  ngOnDestroy() {
    // this.zone.runOutsideAngular(() => {
    //   if (this.chart) {
    //     this.chart.dispose();
    //   }
    // });
  }


  runNorth() {
    
    this.chart.validate();
  }

  sendValue(){

  }

  getRegion(region){
    this.regionDetals=region;
    this.ongetData.emit(this.regionDetals);
  }

  getRegion1(region){
    this.regionDetals=region;
    this.ongetData1.emit(this.regionDetals);
  }

}