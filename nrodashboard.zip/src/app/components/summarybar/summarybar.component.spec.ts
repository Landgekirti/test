import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummarybarComponent } from './summarybar.component';

describe('SummarybarComponent', () => {
  let component: SummarybarComponent;
  let fixture: ComponentFixture<SummarybarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummarybarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummarybarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
