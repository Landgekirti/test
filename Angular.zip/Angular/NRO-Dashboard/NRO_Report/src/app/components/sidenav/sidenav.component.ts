import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    // Sidenav
    $('.navToggle').on('click', function (e) {

      $(this).toggleClass('is-active');
      $('body').toggleClass('mini-sidebar');

      e.preventDefault();
    });

    $('.has-arrow').on('click', function (e) {
      $('#sidebarnav li').removeClass('active');
      $('#sidebarnav .collapse').removeClass('in');
      $(this).next('.collapse').addClass('in');
      $(this).parent().addClass('active');

      e.preventDefault();
    });
  }

}
