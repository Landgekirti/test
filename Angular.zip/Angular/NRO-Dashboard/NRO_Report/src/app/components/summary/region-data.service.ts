import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RegionDataService {

  constructor() { }

  private _regionData: any[]=[];

  get RegionData(): any[] {
    return this._regionData;
  }
  set RegionData(obj: any[]) {
    this._regionData = obj;
  }
}
