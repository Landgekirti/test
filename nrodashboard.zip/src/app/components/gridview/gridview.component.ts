import { Component, OnInit,Input } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { PopUpTableComponent } from './pop-up-table/pop-up-table.component';
import { TaDataSharingService } from './ta-data-sharing.service';

@Component({
  selector: 'app-gridview',
  templateUrl: './gridview.component.html',
  styleUrls: ['./gridview.component.scss']
})
export class GridviewComponent implements OnInit {
  
  @Input() tableDate;
  @Input() searchData;
  @Input() searchData1;
  stateData
  stateData1
  obj;
  searchText;
  searchText1;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService, private MatDialog: MatDialog, public taDataSharingService:TaDataSharingService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    this.stateData=this.tableDate;   
    
    this.searchText=this.searchData;
    this.searchText1=this.searchData1
  }

  ngAfterViewInit(){
    
  }

  displayTAValues()
  {
    
    this.taDataSharingService.TaData=this.tableDate
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass='dialog-lg';
    let dialogRef= this.MatDialog.open(PopUpTableComponent, dialogConfig);
    dialogRef.disableClose=true;
    dialogRef.afterClosed().subscribe((resp)=>
    {
           
    })
  }

}

