import { MatTableDataSource } from "@angular/material";

export class NroTableModel
{
    dataSource:any[]=[]; 

    private _oMatTableDataSource:MatTableDataSource<any[]>;

    get oMatTableDataSource(): MatTableDataSource<any[]> {
        this._oMatTableDataSource = new MatTableDataSource(this.dataSource);
        return this._oMatTableDataSource;
    }
    // set oMatTableDataSource(newName: MatTableDataSource<any[]>) {        
    //     this._oMatTableDataSource = newName;        
    // }

    tableTitle:string;   

    btnAdd:{visible:false};
    btnDelete:{visible:false};
    btnApprove:{visible:false};
    btnDownload:{visible:false};

    onDeleteBtn = false;
    onAddBtn = false;
    onApprovalBtn = false;
    onDownloadBtn = false;
    onCalculateBtn = false;
    onFetchDataBtn = false;
    onSaveBtn = false;
    oncertiDisplay=false;
    onDownloadCertificate=false;
    onCategorizeBtn=false;
    onstatusClick=false;

    btnActionDelete:boolean=false;
    btnActionEdit:boolean=false;
    btnActionDisplay:boolean=false;
    btncertiDisplay:boolean=false;
    btncertiDownload:boolean=false;
    btnstatusDisplay:boolean=true;
    

    colAction:boolean=true;
    colSelect:boolean=true;
    colCerti:boolean=true;
    colDownloadCerti:boolean=true;
    colStatus:boolean=true;

    btnAction:{};

    columnDef:any[]=[];

    displayedColumns:any[]=[];

    headerColumns:any[]=[];

    columns:any[]=[];
    
    selectedRecords:any[]=[];

    

    tableHeader:any[]=null;
    pageSizeOptions:any=[5,10, 25, 100];
    pageSize:any=10;

    isSelectAll:boolean=false;

    

}