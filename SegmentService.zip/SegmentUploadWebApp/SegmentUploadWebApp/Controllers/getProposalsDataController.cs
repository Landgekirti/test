﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;
namespace SegmentUploadWebApp.Controllers
{
     [RoutePrefix("Api/getPointssData")] 
    public class getProposalsDataController : ApiController
    {
         string ConnString = WebConfigurationManager.ConnectionStrings["NROConn"].ConnectionString;

        [HttpPost]
        [Route("GetProposalsDatabyState")]
         public DataSet GetState([FromBody]PointInputValue Input)
         {
             try
             {
                 using (SqlConnection conn = new SqlConnection(ConnString))
                 using (SqlCommand cmd = new SqlCommand("spGetProposalbyStateforKalibrate", conn))
                 {
                     conn.Open();
                     SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                     adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                     adapt.SelectCommand.Parameters.Add(new SqlParameter("@stateInput", SqlDbType.VarChar));
                     adapt.SelectCommand.Parameters["@stateInput"].Value = Input.stateInput;
                     DataSet ds = new DataSet();
                     adapt.Fill(ds);
                     DataTable dt = new DataTable();
                     dt = ds.Tables[0];
                     return ds;
                 }
             }
             catch (Exception e)
             { throw e; }
         }

        //[HttpPost]
        //[Route("GetProposalsData")]
        // public DataSet GetState([FromBody]PointInputValue Input)
        //{
        //    try
        //    {
        //        using (SqlConnection conn = new SqlConnection(ConnString))
        //        using (SqlCommand cmd = new SqlCommand("spGetProposalsDatabyPoint", conn))
        //        {
        //            conn.Open();
        //            SqlDataAdapter adapt = new SqlDataAdapter(cmd);
        //            adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
        //            adapt.SelectCommand.Parameters.Add(new SqlParameter("@PointsInput", SqlDbType.VarChar));
        //            adapt.SelectCommand.Parameters["@PointsInput"].Value = Input.pointInput;
        //            DataSet ds = new DataSet();
        //            adapt.Fill(ds);
        //            DataTable dt = new DataTable();
        //            dt = ds.Tables[0];
        //            return ds;
        //        }
        //    }
        //    catch (Exception e)
        //    { throw e; }
        //}

        [HttpPost]
        [Route("spGetProposalDataforKalibrate")]
        public DataSet GetProposal([FromBody]PointInputValue Input)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetProposalDataforKalibrate", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@proposalNumber", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@proposalNumber"].Value = Input.ProposalNumber;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

        [HttpPost]
        [Route("GetUserRoleForKalibrate")]
        public DataSet GetRole([FromBody]PointInputValue Input)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetUserRoleforKalibrate", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@UserName"].Value = Input.UserName;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

        [HttpPost]
        [Route("saveKalibrateDetailsforKalibrate")]
        public DataSet saveKalibrateDetails([FromBody]PointInputValue Input)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spSaveKalibrateDetailsforKalibrate ", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@proposalNumber", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@proposalNumber"].Value = Input.ProposalNumber;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@segmentIds", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@segmentIds"].Value = Input.segmentIds;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }
    }
}

public class PointInputValue
{
    public string pointInput { get; set; }
    public string stateInput { get; set; }
    public string UserName { get; set; }

    public string ProposalNumber { get; set; }
    public string segmentIds { get; set; }
}