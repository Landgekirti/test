import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { TaDataSharingService } from '../ta-data-sharing.service';


@Component({
  selector: 'app-pop-up-table',
  templateUrl: './pop-up-table.component.html',
  styleUrls: ['./pop-up-table.component.scss']
})
export class PopUpTableComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<PopUpTableComponent>,public taDataSharingService:TaDataSharingService)  { }

  stateDetails
  ngOnInit() {
    this.stateDetails=this.taDataSharingService.TaData;
    
  }

  onClose() {
    this.dialogRef.close();
  }
}
