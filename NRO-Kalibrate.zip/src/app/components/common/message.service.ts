import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit } from '@angular/core';

@Injectable()
export class MessageService implements OnInit {

  constructor(private toastr: ToastrService) { }

  ngOnInit() {
  }

  showNotification() {
    this.toastr.error("Please Enter the valid credentials", 'Error', { positionClass: 'toast-top-center' })
  }

  fileUploadnotification() {
    this.toastr.error("Excel file uploaded has faild, Please check the terms.", 'Error', { positionClass: 'toast-top-center' })
  }

  showunmatchedSegments(segmentOutput, stateInput) {
    this.toastr.error(segmentOutput + " does not belong to " + stateInput, 'Error', { positionClass: 'toast-top-center' })
  }

  SaveKalibrateDetails(proposalNumber) {
    this.toastr.success("Kalibarte details is saved in the: " + proposalNumber, 'Success', { positionClass: 'toast-top-center' })
  }

  segmentsmandatorytosearch() {
    this.toastr.error("Please enter segment", 'Error', { positionClass: 'toast-top-center' })
  }
} 
