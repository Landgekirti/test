import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { LocalSevice } from './../../localservice.service'
import { getData } from '../../services/getData.service'
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { ExcelUploadComponent } from '../../../components/excel-upload/excel-upload.component'
import 'angular-notification-icons'
import { SegmentDetailComponent } from '../../segment-details/segment-details.component';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  constructor(private LocalSevice: LocalSevice, 
              private getData: getData,
              private router: Router,
              private MatDialog: MatDialog) { }
  user
  username
  userRole
  UserdisplayName
  ngOnInit() {
    this.user = JSON.parse(sessionStorage.loginInfo);
    console.log(this.user.userName);
    this.UserdisplayName = this.user.fullName
    this.username = this.user.userName
    //  this.username = sessionStorage.loginInfo.fullName
    this.getUserole();
  }

  getUserole(){
      this.getData.GetUserRole(this.username).subscribe(data=>{
          this.userRole = data.Table[0].Role_Code 
          this.LocalSevice.SetUserRole = this.userRole
        })
  }

  openExcelUpload(){
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.width = '775px'
    dialogConfig.height = '500px'  

    this.MatDialog.open(ExcelUploadComponent, dialogConfig);
  }

  openSegmentComponent(){
      const dialogConfig = new MatDialogConfig();

      dialogConfig.width='1265px';
      dialogConfig.height='590px';
      dialogConfig.maxWidth='none'; 

      this.MatDialog.open(SegmentDetailComponent, dialogConfig)
  }

  onclickLogout(){
    sessionStorage.clear();
    this.router.navigate(['/app-login'])
  }
}
