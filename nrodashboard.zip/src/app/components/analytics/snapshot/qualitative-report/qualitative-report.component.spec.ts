import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualitativeReportComponent } from './qualitative-report.component';

describe('QualitativeReportComponent', () => {
  let component: QualitativeReportComponent;
  let fixture: ComponentFixture<QualitativeReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualitativeReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualitativeReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
