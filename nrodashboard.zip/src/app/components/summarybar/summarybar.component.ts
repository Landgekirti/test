import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription }   from 'rxjs';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
import { array } from '@amcharts/amcharts4/core';


@Component({
  selector: 'app-summarybar',
  templateUrl: './summarybar.component.html',
  styleUrls: ['./summarybar.component.scss']
})
export class SummarybarComponent implements OnInit {
  selectedRegion
  regionSelected='';
  hoveredregion="North"
  mapView:boolean=true;
  summaryHeader:boolean=false;
  cardView:boolean=false;
  pieView:boolean=false;
  tableView:boolean=false;
  _oChangeTrigger: number = 1;
  cardData
  breadcrum="Summary";
  loaderVal:boolean=true;
  serachInput
  serachInput1
  searchText='Assam'
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService) { 
      this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
        // Reload WoW animations when done navigating to page,
        // but you are free to call it whenever/wherever you like
        this.wowService.init(); 
        
      });
    }

  ngOnInit() {
    this.getRegion1(this.hoveredregion);
    this.loaderVal=false;
  }

  ngafterviewinit(){
    
    
  }

  getRegion(data){
      
    this.cardData=data;
    this.regionSelected=data;
    this.mapView=false;
    this.cardView=true;
    this.summaryHeader=true;
    this.getRegionBasedData(data);
  }

  getRegion1(data){
    this.hoveredregion=data;
    
    this.getRegionBasedData1(data);
  }

  selectView(data){
    this.mapView=false;
    this.cardView=false;
    this.pieView=false;
    this.tableView=false;
    this.summaryHeader=true;
    switch(data){
      case 'map':
      this.mapView=true;
      this.summaryHeader=false;
      this.getRegion1(this.regionSelected)
      break;
      case 'card':
      this.cardData=this.regionSelected;
      this.cardView=true;
      this.getRegionBasedData(this.regionSelected);
      break;
      case 'charts':
      this.pieView=true;
      this.getRegionBasedData(this.regionSelected);
      break;
      case 'table':
      this.tableView=true;
      this.getRegionBasedData(this.regionSelected);
      break;
      default :
      break;
    }
  }

  reqObj
  stateDetails
  objForPie
  getRegionBasedData(data){
    this.loaderVal=true;
    this.reqObj={
      "RegionCode": data
    }
    this.httpService.getStateSummary(this.reqObj).subscribe((response) => {
      
       
      this.stateDetails=response;
      this.stateDetails=this.stateDetails.Table
      this.objForPie=[];
      let i=0;
      for(let stateData of this.stateDetails){
        let keyValue
        keyValue=[
         {
          "key":"RO Code Genrated",
          "value":stateData.CompletedCount
         },
         {
          "key":"Proposal Pending",
          "value":stateData.SubmittedCount
         },
         {
          "key":"Proposal Rejected",
          "value":stateData.RejectedCount
         }
        ];
        stateData.piechartInput=keyValue;
        this.objForPie.push(keyValue);
        this._oChangeTrigger++;
      }
      
      this.loaderVal=false;
    }, (error) => {
        
    }
    );
  }

  getRegionBasedData1(data){
    this.reqObj={
      "RegionCode": data
    }
    this.httpService.getStateSummary(this.reqObj).subscribe((response) => {
      
       
      this.stateDetails=response;
      this.stateDetails=this.stateDetails.Table
      
    }, (error) => {
        
    }
    );
  }
  filterSelected(){
    
    //this.getRegion(this.regionSelected)
    if(this.cardView==true){
       
      this.cardView=false;
       
      this.getRegionBasedData(this.regionSelected)
      
      this.cardView=true;
       
    }
    else{
      this.selectedRegion=this.regionSelected;
      this.getRegionBasedData(this.regionSelected)
    }
   
    // this.ngOnInit();
    // this._oChangeTrigger++;
  }

  serachValue(){
    
    this.serachInput=this.searchText;
    this._oChangeTrigger++;
  }
}
