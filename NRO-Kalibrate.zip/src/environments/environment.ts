// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  //local
  //NROPortal:'http://k2rtdev.ril.com/Runtime/Runtime/Form/NRO+Dashboard/',
  // ApiUrl:'http://10.131.133.21/NROKalibrateService/Api',
  
  //dev
  // NROPortal:'http://k2rtdev.ril.com/Runtime/Runtime/Form/NRO+Dashboard/',
  // ApiUrl:'http://10.131.133.21/NROKalibrateService/Api',  
  
  //QA
  NROPortal:'http://bpmsit.jio.com/Runtime/Runtime/Form/NRO+Dashboard/',
  ApiUrl:'http://sjdck2devwfe01.in.ril.com:8080/NROKalibrateService/Api',      
   
  //Jio prod
  // NROPortal:'https://bpmapps.jio.com/Runtime/Runtime/Form/nro%20dashboard',   
  // ApiUrl:'https://wfservices.ril.com/NROPortal/NROKalibrateService/Api',

  //RIL Prod  
  // NROPortal:'https://bpmapps.ril.com/Runtime/Runtime/Form/nro%20dashboard',   
  // ApiUrl:'https://wfservices.ril.com/NROPortal/NROKalibrateService/Api',
};  
  
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
