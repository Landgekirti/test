import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { LocalSevice } from './../localservice.service'
import * as $ from 'jquery';
import { MessageService } from './../common/message.service'
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  status = false
  userName: any;
  welcomePage: boolean = false;
  loginPage: boolean = true;
  cookieUser: any
  formdata: any;
  _user: {
    username: string
    password: string
  }
  public userResponse: any;
  welcome = new BehaviorSubject<boolean>(false);

  constructor(private localservice: LocalSevice,
    private MessageService: MessageService,
    private router: Router) {

    this.formdata = new FormGroup({
      username: new FormControl("", Validators.compose([
        Validators.required
      ])),
      password: new FormControl("", this.passwordvalidation)
    });
  }

  ngOnInit() {
    let user = this.localservice.getloginInfo();
    if (user !== undefined && user !== null) {
      this.userName = user["userName"].replace(".", " ");
    }
  }

  passwordvalidation(formcontrol) {
    if (formcontrol.value.length < 5) {
      return { "password": true };
    }
  }

  onClickSubmit(data) {
    this.userName = data.username
    this.userName = this.userName.replace(".", " ");
    this.localservice.setloginInfo({ "userName": data.username });
    this._user = Object.assign({}, data);
    this.userlogin(this._user)
  }

  userlogin(data) {
    this.localservice.postLogin('https://ssoqa.ril.com', '/login', data, null).subscribe((response: any) => {
      this.userResponse = response.data;
      if (this.userResponse.status == true) {
        this.localservice.setpIdInfo(this.userResponse)
        let loginInfo = { 'userName': data.username, 'status': true, 'fullName': this.userResponse.employeeName ? this.userResponse.employeeName : null, 'pid': this.userResponse.pid ? this.userResponse.pid : null, 'email': this.userResponse.emailID ? this.userResponse.emailID : null };
        this.localservice.setloginInfo(loginInfo);
        this.localservice.setUsernameInfo(loginInfo.fullName);
        this.status = loginInfo.status
      }
      if (this.status == true) {
        this.router.navigate(['/app-main-kalibrate']);
      }
    }, (error) => {
      this.MessageService.showNotification();
    });
  }

}
