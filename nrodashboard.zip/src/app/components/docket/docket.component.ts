import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docket',
  templateUrl: './docket.component.html',
  styleUrls: ['./docket.component.scss']
})
export class DocketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
