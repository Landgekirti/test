import { Component, AfterViewInit } from '@angular/core';
import * as $ from 'jquery';
import { SharedService } from './services/shared.service'
import { CookieService } from 'ngx-cookie-service';
import { Router, NavigationEnd } from '@angular/router';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit {
  title = 'Platform Name';
  
  cookieUser: any;
  sLogout = "false";
  loadAPI: Promise<any>;
  loggedInUser = '';

  constructor(private Localservice: SharedService,
              private _router: Router, 
              private cookieService: CookieService,
              private titlecasePipe: TitleCasePipe)   
  {
    this.loadAPI = new Promise((resolve) => {
      this.loadScript();
      resolve(true);
    });
    this.sLogout = this.Localservice.getParamValueQueryString('logout');

    this._router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.cookieUser = this.cookieService.get('USER');        
        if (this.cookieUser == "" || this.cookieUser == null || this.cookieUser == undefined) {

          let userInfo = sessionStorage.getItem('loginInfo');
          let loggedIn = JSON.parse(userInfo);
          this.loggedInUser = loggedIn.userName.replace('.', ' ');
          this.loggedInUser = this.titlecasePipe.transform(this.loggedInUser);
        }
        else {  
          this.cookieUser = this.cookieService.get('USER');
          this.cookieUser = JSON.parse(this.cookieUser);
          this.loggedInUser = this.cookieUser.domain_id.replace('.', ' ');
          this.loggedInUser = this.titlecasePipe.transform(this.loggedInUser);
        }  

        (<any>window).ga('set', 'dimension1',this.loggedInUser);
        (<any>window).ga('set', 'page', event.urlAfterRedirects);
        (<any>window).ga('send', 'pageview');
      }
    });
  }

  ngOnInit() {
    this.cookieUser = this.cookieService.get('USER');

    this.cookieUser = JSON.parse(this.cookieUser);
    let loginInfo = {
      'userName': this.cookieUser.domain_id ? this.cookieUser.domain_id : '',
      'status': true,
      "fullName": this.cookieUser.fullname ? this.cookieUser.fullname : '',
      'pid': this.cookieUser.employee_id ? this.cookieUser.employee_id : null,
      'email': this.cookieUser.email ? this.cookieUser.email : ''
    };
    this.Localservice.setloginInfo(loginInfo);

    this.loggedInUser = this.cookieUser.domain_id.replace('.', ' ');
    this.Localservice.setloggedIn(this.loggedInUser);
    
    if (this.sLogout === 'true') {      
      this.cookieService.delete('USER', '/', '.ril.com');
    }

    if (document.cookie.indexOf('USER=') == -1) {
      this._router.navigate(['/login'])
    }
    else {
      let sessionRoute = this.Localservice.getRouteData().route;
      if (sessionRoute === null || sessionRoute === '' || sessionRoute === undefined) {
        this.setSessionInfo()
        this._router.navigate(['/home'])
      }
      else {
        this._router.navigate([sessionRoute]);
      }
    }
  }

  ngAfterViewInit() {
    $('#awz-preloader').delay(350).fadeOut(function() {
        $('body').delay(350);
    });
  }

  setSessionInfo() {
    this.cookieUser = this.cookieService.get('USER')
    this.cookieUser = JSON.parse(this.cookieUser)
    let loginInfo = {
      'userName': this.cookieUser.domain_id ? this.cookieUser.domain_id : '',
      'status': true,
      "fullName": this.cookieUser.fullname ? this.cookieUser.fullname : '',
      'pid': this.cookieUser.employee_id ? this.cookieUser.employee_id : null,
      'email': this.cookieUser.email ? this.cookieUser.email : ''
    };
    this.Localservice.setloginInfo(loginInfo);
  }


  public loadScript() {
    var isFound = false;
    var scripts = document.getElementsByTagName("script")
    for (var i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
        isFound = true;
      }
    }

    if (!isFound) {
      var dynamicScripts = ["./assets/js/plugins.js", "./assets/js/mainPlugin.js"];

      for (var i = 0; i < dynamicScripts.length; i++) {
        let node = document.createElement('script');
        node.src = dynamicScripts[i];
        node.type = 'text/javascript';
        node.async = false;
        node.charset = 'utf-8';
        document.getElementsByTagName('head')[0].appendChild(node);
      }  

    }
  }
}
  