import { Component, OnInit, Input, NgZone} from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../../services/http-calls.service';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent implements OnInit {

  @Input() oInputPiedata;
  @Input() oInputPiediv;
  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService,private zone: NgZone){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    $(function(){
          function equalHeight(){
              var heightArray = $(".pie-con").map( function(){
                  return  $(this).height();
              }).get();
              
              var maxHeight = Math.max.apply( Math, heightArray);
                  $(".pie-con").height(maxHeight);
              }
          equalHeight();
    });
    //this.generateChart(this.oInputPiedata,this.oInputPiediv);
  }

  ngAfterViewInit(){
    this.generateChart(this.oInputPiedata,this.oInputPiediv);
    var lenghtOfLogo = document.getElementsByTagName('title').length;
    for(let i=0;i<lenghtOfLogo;i++){
      var logo = document.getElementsByTagName('title')[i].parentElement;
      logo.style.display = "none";
    }
    
  }

  generateChart(data,id){

    //var self=this;
    this.zone.runOutsideAngular(() => {

      let chart = am4core.create(id, am4charts.PieChart);
      
      // Add data
      chart.data =data
      
      // Add and configure Series
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "value";
      pieSeries.dataFields.category = "key";
      pieSeries.hiddenState.properties.opacity = 5;
      pieSeries.hiddenState.properties.endAngle = -90;
      pieSeries.hiddenState.properties.startAngle = -90;
      pieSeries.alignLabels = false;
      pieSeries.labels.template.text = '';
      pieSeries.colors.list = [
        am4core.color("#608bfe"),
        am4core.color("#3bcac6"),
        am4core.color("#ffbb4b"),
        am4core.color("#5cd049"),
        am4core.color("#FFC75F"),
        am4core.color("#F9F871"),
      ];
  
      chart.legend = new am4charts.Legend();
      chart.legend.useDefaultMarker = true;
      let marker = chart.legend.markers.template.children.getIndex(0);
      marker.width = 15;
      marker.height = 15;
      //marker.cornerRadius(12, 12, 12, 12);
      marker.strokeWidth = 2;
      marker.strokeOpacity = 1;
      marker.stroke = am4core.color("#ccc");
      
    });

  }
}
