﻿using Newtonsoft.Json.Linq;
using SourceCode.Hosting.Client.BaseAPI;
using SourceCode.SmartObjects.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;

namespace AngularConsolidated.Controllers
{
    [POCAngularCORSPolicy]
    public class AngularServiceController : ApiController
    {

        string _sURL = string.Empty;
        
        
        [Route("api/AngularService/GetMyPendingTasks/AuthVal")]
        public List<WorkFlowModel> Get(string AuthVal, string WFName)
        {
            try
            {
                if (!string.IsNullOrEmpty(WFName.Trim()) && !string.IsNullOrEmpty(AuthVal.Trim()))
                {
                    _sURL = Convert.ToString(ConfigurationManager.AppSettings["K2URL"]);
                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri(_sURL);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));                    

                        HttpResponseMessage response = client.GetAsync("Api/Workflow/V1/tasks?state=All").Result;
                        HttpContent content = response.Content;
                        Task<string> responseWF = content.ReadAsStringAsync();
                        if (response.IsSuccessStatusCode)
                        {
                            List<WorkFlowModel> lstWorkFlow = new List<WorkFlowModel>();
                            JObject jObj = JObject.Parse(responseWF.Result);
                            JToken jTask = jObj["tasks"];
                            for (int i = 0; i < Convert.ToInt32(jObj["itemCount"]); i++)
                            {
                                WorkFlowModel model = new WorkFlowModel();
                                model.serialNumber = (string)jTask[i]["serialNumber"];
                                model.workflowDisplayName = (string)jTask[i]["workflowDisplayName"];
                                model.activityInstanceDestinationID = (int)jTask[i]["activityInstanceDestinationID"];
                                model.activityInstanceID = (int)jTask[i]["activityInstanceID"];
                                model.activityName = (string)jTask[i]["activityName"];
                                model.taskStartDate = (string)jTask[i]["taskStartDate"];
                                model.workflowCategory = (string)jTask[i]["workflowCategory"];
                                model.status = (string)jTask[i]["status"];
                                model.workflowInstanceFolio = (string)jTask[i]["workflowInstanceFolio"];
                                model.workflowName = (string)jTask[i]["workflowName"];
                                model.eventName = (string)jTask[i]["eventName"];
                                model.eventDescription = (string)jTask[i]["eventDescription"];
                                model.viewFlowURL = (string)jTask[i]["viewFlowURL"];
                                model.formURL = (string)jTask[i]["formURL"];                            
                                model.workflowInstanceID = (string)jTask[i]["workflowInstanceID"];
                                // var obj =   (string)jTask[i]["actions"];
                                lstWorkFlow.Add(model);
                            }

                            //var L1list = lstWorkFlow.Where(a => a.workflowDisplayName == "DT_WF_L2").ToList();
                            List<WorkFlowModel> lstResult = new List<WorkFlowModel>();          
                            String[] arrWFName = WFName.Split(',');
                            if (arrWFName != null && arrWFName.Length > 0)
                            {
                                foreach (String strWFName in arrWFName)
                                {
                                    if (!string.IsNullOrEmpty(strWFName.Trim()))
                                    {
                                        List<WorkFlowModel> lstL1 = lstWorkFlow.Where(a => a.workflowDisplayName == strWFName.Trim()).ToList();
                                        lstResult.AddRange(lstL1);
                                    }
                                }
                            }
                            return lstResult;
                        }
                        else
                        {
                            return null;
                       

                        }
                    }
                }
                else{
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
             
            }
           
        }




        [HttpPost]
        [Route("api/AngularService/StartWkFInstance/AuthVal")]
        public string StartWkFInstance(int WorkFlowID, [FromBody]WorkFlowModel1 model, string AuthVal)
        {
           // model.folio = "TestAngularTest4545";
            //model.dataFields.Approver1 = "mrunal.gaikwad;vishal.ujjain";
            //model.dataFields.Approver2 = "mrunal.gaikwad;kushal.gosar";
            HttpResponseMessage response = null;
            HttpContent content = null;
            Task<string> strProcessId = null;
            try
            {
                using (var client = new HttpClient())
                {
                    //client.BaseAddress = new Uri("http://devk2rt.ril.com/");
                    _sURL = Convert.ToString(ConfigurationManager.AppSettings["K2URL"]);
                    if (!string.IsNullOrEmpty(_sURL))
                    {
                        client.BaseAddress = new Uri(_sURL);
                        client.DefaultRequestHeaders.Accept.Clear();
                        if (!string.IsNullOrEmpty(AuthVal))
                        {
                            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);
                            if (WorkFlowID > 0 && model != null)
                            {
                                response = client.PostAsJsonAsync<WorkFlowModel1>("Api/Workflow/V1/workflows/" + WorkFlowID, model).Result;
                                if (response != null)
                                    content = response.Content;
                                if (content != null)
                                    strProcessId = content.ReadAsStringAsync();
                            }
                        }
                    }
                    
                    // client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", "SU5cbXJ1bmFsLmdhaWt3YWQ6cXdlcnR5QDEyMw==");

                    if (response.IsSuccessStatusCode && !string.IsNullOrEmpty(strProcessId.Result))
                    {
                        return Convert.ToString(strProcessId.Result);
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //[HttpPost]
        //[Route("api/pocstartwkf/TakeCustomWKFAction/SerialNumber/ActionType")]
        //public string TakeCustomWKFAction(string SerialNumber, string ActionType, [FromBody]WorkFlowModel model, string AuthVal)
        //{
        //    try
        //    {
        //        using (var client = new HttpClient())
        //        {
        //            client.BaseAddress = new Uri("http://devk2rt.ril.com/");
        //            client.DefaultRequestHeaders.Accept.Clear();
        //            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);
                   
                    
        //            HttpContent paramContent = new StringContent(@"");
        //            //HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/" + ActionType,).Result;
        //            HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/" + ActionType, paramContent).Result;

        //            HttpContent content = response.Content;
        //            Task<string> abc = content.ReadAsStringAsync();


        //            if (response.IsSuccessStatusCode)
        //            {
        //                return Convert.ToString(abc.Result);
        //            }
        //            else
        //            {
        //                return "hi.. you are not Authorized to take action";
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}


        [HttpPost]
        [Route("api/pocstartwkf/TakeCustomWKFAction/SerialNumber/ActionType")]
        public string TakeCustomWKFAction(string SerialNumber, string ActionType, string AuthVal)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    //client.BaseAddress = new Uri("http://devk2rt.ril.com/");
                    _sURL = Convert.ToString(ConfigurationManager.AppSettings["K2URL"]);
                    client.BaseAddress = new Uri(_sURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);                 


                    HttpContent paramContent = new StringContent(@"");
                    //HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/" + ActionType,).Result;
                    HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/" + ActionType, paramContent).Result;

                    HttpContent content = response.Content;
                    Task<string> responseWF = content.ReadAsStringAsync();


                    if (response.IsSuccessStatusCode)
                    {
                        if (responseWF != null)
                        {
                            //code = HttpStatusCode.OK;
                            return responseWF.Result;
                        }
                        else
                        {
                            return null;
                        }                       

                    }
                    else
                    {
                        return "You are not Authorized.";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }




        [HttpPost]
        [Route("api/pocstartwkf/RedirectWKFAction/SerialNumber/Actions/Redirect")]
        public string RedirectWKFAction(string SerialNumber, [FromBody]WorkFlowModelRedirect model, string AuthVal)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    //client.BaseAddress = new Uri("http://devk2rt.ril.com/");
                    _sURL = Convert.ToString(ConfigurationManager.AppSettings["K2URL"]);
                    client.BaseAddress = new Uri(_sURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);


                    HttpContent paramContent = new StringContent(@"");
                    //HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/" + ActionType,).Result;
                    HttpResponseMessage response = client.PostAsync("Api/Workflow/V1/tasks/" + SerialNumber + "/actions/redirect", paramContent).Result;

                    HttpContent content = response.Content;
                    Task<string> abc = content.ReadAsStringAsync();


                    if (response.IsSuccessStatusCode)
                    {
                        return Convert.ToString(abc.Result);
                    }
                    else
                    {
                        return "You are not Authorized to take action";
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        [HttpPost]
        [Route("api/AngularService/GetTaskDetails/")]
        public string StartWkFInstance(string SerialNumber, string AuthVal)
        {
            
            try
            {
                using (var client = new HttpClient())
                {
                    //client.BaseAddress = new Uri("http://devk2rt.ril.com/");
                    _sURL = Convert.ToString(ConfigurationManager.AppSettings["K2URL"]);
                    client.BaseAddress = new Uri(_sURL);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", AuthVal);

                    HttpResponseMessage response = client.GetAsync("Api/Workflow/V1/tasks/" + SerialNumber).Result;

                    HttpContent content = response.Content;
                    Task<string> abc = content.ReadAsStringAsync();


                    if (response.IsSuccessStatusCode)
                    {


                        return Convert.ToString(abc.Result);
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        // POST api/angularservice
        public void Post([FromBody]string value)
        {
        }

        // PUT api/angularservice/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/angularservice/5
        public void Delete(int id)
        {
        }

       [HttpPost]
        [Route("api/AngularService/UMUser/GetUserDetails/")]
        public void Get(string UserFQNName)
        {
            //Build up a connection string with the SCConnectionStringBuilder
            SourceCode.Hosting.Client.BaseAPI.SCConnectionStringBuilder hostServerConnectionString = new SCConnectionStringBuilder();

            hostServerConnectionString.Host = WebConfigurationManager.AppSettings["Hostname"];  //name of the K2 host server, or the name of the DNS entry pointing to the K2 Farm

            hostServerConnectionString.Port = Convert.ToUInt32(WebConfigurationManager.AppSettings["Port"]); //use port 5555 for all non-workflow client connections

            hostServerConnectionString.IsPrimaryLogin = true; //true = re-authenticate user, false = use cached security credentials

            hostServerConnectionString.Integrated = true; //true = use the logged on user, false = use the specified user
            //Open the connection to K2

            SourceCode.SmartObjects.Client.SmartObjectClientServer soServer = new SmartObjectClientServer();
            soServer.CreateConnection();
            soServer.Connection.Open(hostServerConnectionString.ToString());
            
           // instantiate the SmartObject you wish to run
            SmartObject mySmO = soServer.GetSmartObject("UMUser");
            mySmO.Properties["FQN"].Value = UserFQNName;
            mySmO.MethodToExecute = "Get_User_Details";
          
            soServer.ExecuteScalar(mySmO);
          
        }

  }
}

public class WorkFlowModel
{
    public string serialNumber { get; set; }
    public string workflowDisplayName { get; set; }
    public string status { get; set; }
    public string taskStartDate { get; set; } 
    public int priority { get; set; }
    public string formURL { get; set; }
    public string viewFlowURL { get; set; }
    public int workflowID { get; set; }
    public string workflowName { get; set; }
    public string workflowCategory { get; set; }
    public string workflowInstanceID { get; set; } 
    public string workflowInstanceFolio { get; set; }
    public int activityInstanceID { get; set; }
    public int activityInstanceDestinationID { get; set; }
    public string activityName { get; set; }
    public string eventName { get; set; }
    public string eventDescription { get; set; } 
  

}

public class WorkFlowModelRedirect
{
    public string RedirectTo { get; set; }
  
}
public class WorkFlowModel1
{
    public string folio { get; set; }

    public DataFieldObj dataFields { get; set; }
}

public class DataFieldObj
{
  

    public string Approver1 { get; set; }

    public string Approver2 { get; set; }
}



public class POCAngularCORSPolicy : Attribute, ICorsPolicyProvider
{
    private CorsPolicy _policy;

    public POCAngularCORSPolicy()
    {
        // Create a CORS policy. 
        _policy = new CorsPolicy
        {
            AllowAnyMethod = true,
            AllowAnyHeader = true
        };

        // Add allowed origins. 
        var origins = Convert.ToString(ConfigurationManager.AppSettings["CORSOrigin"]);
        _policy.Origins.Add(origins);

    }

    public Task<CorsPolicy> GetCorsPolicyAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        return Task.FromResult(_policy);
    }
}