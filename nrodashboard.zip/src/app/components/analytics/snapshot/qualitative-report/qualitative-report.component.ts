import { Component, OnInit } from '@angular/core';
import { HttpCallsService } from '../../../../services/http-calls.service';
@Component({
  selector: 'app-qualitative-report',
  templateUrl: './qualitative-report.component.html',
  styleUrls: ['./qualitative-report.component.scss']
})
export class QualitativeReportComponent implements OnInit {

  constructor(public httpService:HttpCallsService) { }
  regionCode='';
  stateFilter='';
  districtFilter='';
  roadClasFilter='';
  categoryFilter='';
  subCategoryFilter='';
  volCatTAFilter='';
  volCatPVFilter='';
  meFilter='';
  loaderVal:boolean=true;
  current;

  ngOnInit() {
    this.getFilteredData();
  }

  reportDetails
  reqObject
  getFilteredData(){
    this.loaderVal=true;
    // const formData = new FormData();
    // formData.append('RegionCode', this.regionCode);
    // formData.append('StateFilter', this.stateFilter);
    // formData.append('DistrictFilter', this.districtFilter);
    // formData.append('RoadClasFilter', this.roadClasFilter);
    // formData.append('CategoryFilter', this.categoryFilter);
    // formData.append('SubCategoryFilter', this.subCategoryFilter);
    // formData.append('VolCatTAFilter', this.volCatTAFilter);
    // formData.append('VolCatPVFilter', this.volCatPVFilter);
    // formData.append('MEFilter', this.meFilter);
    this.reqObject={
      "RegionCode":this.regionCode,
      "StateFilter":'',
      "DistrictFilter" :'',
      "RoadClasFilter":'',
      "CategoryFilter":'',
      "SubCategoryFilter" :'',
      "VolCatTAFilter":'',
      "VolCatPVFilter":'',
      "MEFilter":''
    }
    this.httpService.getFilterDataquant(this.reqObject).subscribe((response) => {
      
      this.reportDetails=response;
      this.loaderVal=false;
    }, (error) => {
    }
    );
  }

  getFilterValues(data){
    
  }
}
