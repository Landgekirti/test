import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { proposalMapComponent } from './proposal-map.component';

describe('proposalMapComponent', () => {
  let component: proposalMapComponent;
  let fixture: ComponentFixture<proposalMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ proposalMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(proposalMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
