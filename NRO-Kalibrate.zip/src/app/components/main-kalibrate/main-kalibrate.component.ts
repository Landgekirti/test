import { Component, OnInit, Renderer2, ViewChild, ElementRef, AfterViewInit, Input } from '@angular/core';
import { getData } from '../Services/getData.service'
import { FormGroup, FormControl } from '@angular/forms';
import * as $ from 'jquery';
import { LocalSevice } from './../localservice.service'
import { Router, NavigationEnd } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { PointsComparisonComponent } from '../points-comparison/points-comparison.component';
import { MessageService } from './../common/message.service';
import { proposalMapComponent } from '../../components/common/proposal-Map/proposal-Map.component';
import { environment } from 'src/environments/environment'
  
@Component({
  selector: 'app-main-kalibrate',
  templateUrl: './main-kalibrate.component.html',
  styleUrls: ['./main-kalibrate.component.scss']
})
export class MainKalibrateComponent implements OnInit, AfterViewInit {
  stateInput; segmentOutput: string = null; username;fullName; user; /* Input variables */
  States; allPoints; ProposalData; UserRole: String /* API data retrivals */
  segmentDynamicInput: string = null; segmentDynamicInputLenght; /* dynamic segment box variables */
  HideShowFlag: Boolean = false; AddProposalFlag = false; EditProposalFlag = false; boxshowFlag: Boolean = true;  /* flags */
  private window: any = window;

  PerPageRecords: {};
  Records: {};
  pointPerPage: Number = 5;
  proposalPerPage: Number = 5;
  PointIds: String = null;NROPortal;
  // RefreshFlag;

  constructor(private getData: getData,
    private renderer: Renderer2,
    private localSevice: LocalSevice,
    private router: Router,
    private matDialog: MatDialog,
    private MessageService: MessageService) {
      this.NROPortal = environment.NROPortal
  }

  ngOnInit() {
    this.getState()
    this.PerPageRecords = [{ "Value": 3 }, { "Value": 5 }, { "Value": 10 }, { "Value": 25 }, { "Value": 50 }, { "Value": 100 }, { "Value": 200 }]
    this.user = JSON.parse(sessionStorage.loginInfo);
    this.username = this.user.userName;
    console.log('Before------',this.user.fullName)
    this.fullName = this.user.fullName.replace(' (Consultant)','')
    console.log('After------',this.fullName)
    this.getUserole();
    this.segmentDynamicInput = null;
  }
  
  ngAfterViewInit() {
    // To disable special characters and alphabets in segment input
    // To set maxlenght of segment Input
    $("#segmentInputDiv").on({
      keydown: function (e) {
        if (e.which === 46 || e.which === 8 || e.which === 9 || e.which === 49 || e.which === 50 || e.which === 51 || e.which === 52 || e.which === 53 || e.which === 54 || e.which === 55 || e.which === 56 || e.which === 57 || e.which === 48)
        {    
          $(".InputClass").attr('maxlength','8'); 
        return true;
        }
        else 
          return false;
      },
    });

  }

  DivVisibility() {
    $(".backgroundImage").css({ "height": "96vh" });
    this.HideShowFlag = false;
    $(".InputClass").val('');
    if (this.stateInput != null) {  
      this.boxshowFlag = false;
    }
    else {
      this.boxshowFlag = true;
    }
  }

  getUserole() {
    this.getData.GetUserRole(this.username).subscribe(data => {
      this.UserRole = data.Table[0].Role_Code;
      if ((this.UserRole == "AM") || (this.UserRole == "NDM")) {
        this.AddProposalFlag = true
      }
      else {
        this.AddProposalFlag = false
      }

      if ((this.UserRole == "AM") || (this.UserRole == "NDM") || (this.UserRole == "SBDM")) {
        this.EditProposalFlag = true
      }
      else {
        this.EditProposalFlag = false
      }
    })
  }

  onClickAddProposal() {
    //window.open('http://devk2rtazure.ril.com/Runtime/Runtime/Form/NRO+Dashboard/','_blank') //DevAzure
    //window.open('http://bpmsit.jio.com/Runtime/Runtime/Form/NRO+Dashboard/', '_blank')  //QA
    //window.open('http://k2rtdev.ril.com/Runtime/Runtime/Form/NRO+Dashboard/', '_blank')  //Dev

    window.open(this.NROPortal,'_blank')
  }

  OnClickEdit(proposal_number, url) {
    this.getData.SaveKalibrateDetails(this.segmentDynamicInput, proposal_number).subscribe(data => {
      this.getProposals();
    })
    window.open(url, '_blank')
    //window.open('http://k2rtdev.ril.com/Runtime/Runtime/Form/Trading+Area+Profile+Form/?&p_proposal_no='+proposal_number,'_blank')
  }

  getState() {
    this.getData.getState().subscribe(data => {
      this.States = data.Table;
    });
  }

  addInput() {
    const input = this.renderer.createElement('input');
    const segmentDiv = document.getElementById('segmentInputDiv');
    this.renderer.appendChild(segmentDiv, input);
    this.renderer.addClass(input, 'InputClass');
  }

  serachbySegments() {
    // this.localSevice.SegmentDynamicInput = this.segmentDynamicInput
    this.segmentOutput = null
    this.getSegmentIds();
    if (this.segmentDynamicInput == null) {
      this.MessageService.segmentsmandatorytosearch();
    }
    else {
      this.getData.CheckSegmentsState(this.segmentDynamicInput, this.stateInput).subscribe(data => {
        for (var i = 0; i < Object.keys(data.Table).length; i++) {
          this.segmentOutput = this.segmentOutput + ',' + JSON.stringify(data.Table[i].segment)
        }
        if (this.segmentOutput == null) {
          this.localSevice.state = this.stateInput;
          this.getSegmentIds();
          this.localSevice.SegmentIds = this.segmentDynamicInput;
          this.getPoints();
          this.getProposals();
          this.HideShowFlag = true;
          $(".backgroundImage").css({ "height": "100%" });
        }
        else {
          this.segmentOutput = this.segmentOutput.replace('null,', '')
          this.MessageService.showunmatchedSegments(this.segmentOutput, this.stateInput);
          this.HideShowFlag = false;
        }
      })
    }
  }

  getSegmentIds() {
    this.segmentDynamicInput = null
    const value = (<HTMLScriptElement[]><any>document.getElementsByClassName('InputClass'));
    this.segmentDynamicInputLenght = value.length
    for (var i = 0; i < this.segmentDynamicInputLenght; i++) {
      if ($(".InputClass")[i].value != '') {
        this.segmentDynamicInput = (this.segmentDynamicInput + ',' + $(".InputClass")[i].value)
      }
    }
  }

  getPoints() {
    this.getData.GetPointsbySegmentId(this.segmentDynamicInput).subscribe(data => {
      this.allPoints = data.Table
      for (var i = 0; i <= Object.keys(data.Table).length; i++) {
        this.PointIds = this.PointIds + ',' + data.Table[i].PointID
      }
      //   this.getInput.allPointsData = JSON.stringify(this.allPoints)
    })
  }

  getProposals() {
    this.getData.GetProposalbyStates(this.stateInput).subscribe(data => {
      this.ProposalData = data.Table
      this.localSevice.allProposalsData = this.ProposalData
    })
  }

  openDialogforPointComparison(proposalNumber) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.width = '1085px';
    dialogConfig.height = '590px';

    this.matDialog.open(PointsComparisonComponent, dialogConfig)
    this.localSevice.proposalNumber = proposalNumber;
  }

  OnClickAddDetails(proposalNumber) {
    this.getData.SaveKalibrateDetails(this.segmentDynamicInput, proposalNumber).subscribe(data => {
      this.getProposals();
    })
    this.MessageService.SaveKalibrateDetails(proposalNumber);
  }

  openDialogforMap() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.width = '900px';
    dialogConfig.height = '550px';

    this.matDialog.open(proposalMapComponent, dialogConfig);
  }

  OnClickPlotMap(){
    window.open('http://nvmbd1bkh150v02.rjil.ril.com/NRO_Portal/?segmentIdinput='+this.segmentDynamicInput,'_blank');
  }

  resetInput(){
    this.stateInput = null
    this.DivVisibility();
  }
}
