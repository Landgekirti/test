import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})  

export class SharedService {
    public loggedInUser;
    public username;
    public UserRole;
    cookieUser: any;
    apiUrl = environment.apiUrl;
    headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
    private _wso2Option: any = { 
        'Content-Type': 'application/json', 
        withCredentials:true
    };

    private _options: any = { 'Content-Type': 'application/json' };
    constructor(private _http: HttpClient,
                private cookieService: CookieService,
                private router: Router) { }
   
    
    setloggedIn(obj){
        this.loggedInUser = obj
    }

    getloggedIn(){ 
        return this.loggedInUser
    }

    setloginInfo(data1) {
        ////og("data1");
        //og(data1);
        sessionStorage.loginInfo = JSON.stringify(data1);
    }

    setpIdInfo(data) {
        sessionStorage.pIdInfo = JSON.stringify(data);
    }

    getloginInfo() {
        if (sessionStorage.loginInfo) {
            return JSON.parse(sessionStorage.loginInfo);
        } else {
            return null;
        }
    }

    setUsernameInfo(username) {
        this.username = username
    }
    
    get getUsername() {
        return this.username
    }

    set SetUserRole(Role) {
        this.UserRole = Role
    }

    getUserRole() {
        return this.UserRole
    }

    getRouteData(): any {
        if (sessionStorage.routeInfo == null) {
          return "";
        }
        else
          return JSON.parse(sessionStorage.routeInfo);
      }
      
    postLogin(url, endpoint, data, params = null, headers = false) {
        const that = this;
        if (headers) {
            this._options.append('Content-Type', 'multipart/form-data');
        }
        let headerss = new HttpHeaders({
            'Content-Type': 'application/json',
            // 'Authorization': 'Bearer ' + this._tokenData
        })
        const queryString = params ? that._objectToQueryString(params) : '';
        // endpoint = CONST['apiEndPoint'][endpoint] + (queryString ? '?' + queryString : '');
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        return that._http.post(url + endpoint, data, this._wso2Option );//{ headers: headerss, withCredentials: true }
    }

    private _objectToQueryString(object) {
        return Object
            .keys(object)
            .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(object[key])}`)
            .join('&');
    }

    getParamValueQueryString(paramName) {
        const url = window.location.href;
        let paramValue;
        if (url.includes('?')) {
          const httpParams = new HttpParams({ fromString: url.split('?')[1] });
          paramValue = httpParams.get(paramName);
        }
        return paramValue;
      }
    
      GetUserRole(UserName): Observable<any> {
        let data = new HttpParams().set('UserName', UserName)
        return this._http.request('POST', this.apiUrl + '/getPointssData/GetUserRoleForKalibrate', { body: data, headers: this.headers });
    }

    // GetUserIdbyDomain(domain): Observable<any>{  
    //     let data = new HttpParams().set('DomainID', domain)
    //     return this._http.request('POST','http://10.21.52.158/NROCNPTEmpDetailService/WebService1.asmx?op=EmpInfoByDomain', { body: data, headers: this.headers});
    // }
}      