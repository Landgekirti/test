import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
@Component({
  selector: 'app-summary-more',
  templateUrl: './summary-more.component.html',
  styleUrls: ['./summary-more.component.scss']
})
export class SummaryMoreComponent implements OnInit {

  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  
  }

  ngOnInit() {
    $(function(){
          function equalHeight(){
              var heightArray = $(".white-box2").map( function(){
                  return  $(this).height();
              }).get();
              
              var maxHeight = Math.max.apply( Math, heightArray);
                  $(".white-box2").height(maxHeight);
              }
          equalHeight();
    });     
  }

}
