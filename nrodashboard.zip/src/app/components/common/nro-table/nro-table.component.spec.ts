import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NroTableComponent } from './nro-table.component';

describe('NroTableComponent', () => {
  let component: NroTableComponent;
  let fixture: ComponentFixture<NroTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NroTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NroTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
