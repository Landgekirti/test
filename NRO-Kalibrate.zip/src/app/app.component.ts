import { Component } from '@angular/core';
import { LocalSevice } from './components/localservice.service'
import { CookieService } from 'ngx-cookie-service';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'NRO-Kalibrate';
  loggedInUser = '';
  cookieUser: any;
  constructor(private Localservice: LocalSevice, 
              private _router: Router,
              private cookieService: CookieService) {
  }

  ngOnInit() {
    this.cookieUser = this.cookieService.get('USER');

    this.cookieUser = JSON.parse(this.cookieUser);
    let loginInfo = {
      'userName': this.cookieUser.domain_id ? this.cookieUser.domain_id : '',
      'status': true,
      "fullName": this.cookieUser.fullname ? this.cookieUser.fullname : '',
      'pid': this.cookieUser.employee_id ? this.cookieUser.employee_id : null,
      'email': this.cookieUser.email ? this.cookieUser.email : ''
    };
    this.Localservice.setloginInfo(loginInfo);  

    this.loggedInUser = this.cookieUser.domain_id.replace('.', ' ');
    this.Localservice.setUsernameInfo(this.loggedInUser);

    if (document.cookie.indexOf('USER=') == -1) {
      this._router.navigate(['/login'])
    }
    else {
      let sessionRoute = this.Localservice.getRouteData().route;
      if (sessionRoute === null || sessionRoute === '' || sessionRoute === undefined) {
        this.setSessionInfo()
        this._router.navigate(['/app-main-kalibrate'])
      }
      else {
        this._router.navigate([sessionRoute]);
      }
    }
  }

  setSessionInfo() {
    this.cookieUser = this.cookieService.get('USER')
    this.cookieUser = JSON.parse(this.cookieUser)
    let loginInfo = {
      'userName': this.cookieUser.domain_id ? this.cookieUser.domain_id : '',
      'status': true,
      "fullName": this.cookieUser.fullname ? this.cookieUser.fullname : '',
      'pid': this.cookieUser.employee_id ? this.cookieUser.employee_id : null,
      'email': this.cookieUser.email ? this.cookieUser.email : ''
    };
    this.Localservice.setloginInfo(loginInfo);
  }
}
