import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class LocalSevice {

    private _options: any = { 'Content-Type': 'application/json' };
    constructor(private _http: HttpClient) { }

    private SegmentId: String[]
    private PointInput: String[]
    private SegmentIdInput
    private State;
    private Dis;
    private allProposals;
    private username: String;
    private UserRole;
    private ProposalNumber;
    public loggedInUser;

    // set SegmentDynamicInput(obj){
    //     this.SegmentDynamicInput = obj;
    // }

    // get SegmentDynamicInput(){
    //     return this.SegmentDynamicInput
    // }

    setloggedIn(obj){
        this.loggedInUser = obj
    }

    getloggedIn(){ 
        return this.loggedInUser
    }

    getRouteData(): any {
        if (sessionStorage.routeInfo == null) {
          return "";
        }
        else
          return JSON.parse(sessionStorage.routeInfo);
      }
      
    get SegmentIds() {
        return this.SegmentIdInput;
    }

    set SegmentIds(obj) {
        this.SegmentIdInput = obj;
    }
    get PointData() {
        return this.PointInput;
    }

    set PointData(obj) {
        this.PointInput = obj;
    }

    get state() {
        return this.State;
    }

    set state(state) {
        this.State = state;
    }

    get District() {
        return this.Dis;
    }

    set District(dis) {
        this.Dis = dis;
    }

    set allProposalsData(allProposals) {
        this.allProposals = allProposals;
    }

    get allProposalsData() {
        return this.allProposals
    }

    setloginInfo(data1) {
        ////og("data1");
        //og(data1);
        sessionStorage.loginInfo = JSON.stringify(data1);
    }

    setpIdInfo(data) {
        sessionStorage.pIdInfo = JSON.stringify(data);
    }

    getloginInfo() {
        if (sessionStorage.loginInfo) {
            return JSON.parse(sessionStorage.loginInfo);
        } else {
            return null;
        }
    }

    setUsernameInfo(username) {
        this.username = username
    }
    
    get getUsername() {
        return this.username
    }

    set SetUserRole(Role) {
        this.UserRole = Role
    }

    getUserRole() {
        return this.UserRole
    }

    postLogin(url, endpoint, data, params = null, headers = false) {
        const that = this;
        if (headers) {
            this._options.append('Content-Type', 'multipart/form-data');
        }
        let headerss = new HttpHeaders({
            'Content-Type': 'application/json',
            // 'Authorization': 'Bearer ' + this._tokenData
        })
        const queryString = params ? that._objectToQueryString(params) : '';
        // endpoint = CONST['apiEndPoint'][endpoint] + (queryString ? '?' + queryString : '');
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        return that._http.post(url + endpoint, data, { headers: headerss, withCredentials: true });
    }

    private _objectToQueryString(object) {
        return Object
            .keys(object)
            .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(object[key])}`)
            .join('&');
    }

    get proposalNumber() {
        return this.ProposalNumber;
    }

    set proposalNumber(obj) {
        this.ProposalNumber = obj;
    }
}