﻿using ExcelDataReader;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
//using SegmentUploadWebApp.Models; 

namespace SegmentUploadWebApp.Controllers
{
    [RoutePrefix("Api/SegmentExcel")]
    public class SegmentController : ApiController
    {

        [Route("UploadExcel")]
        [HttpPost]
        public string ExcelUpload()
        {
            string message = "";
            HttpResponseMessage result = null;
            var httpRequest = HttpContext.Current.Request;
            using (dbKalibrateEntities1 objEntity = new dbKalibrateEntities1())
            {

                if (httpRequest.Files.Count > 0)
                {
                    HttpPostedFile file = httpRequest.Files[0];
                    Stream stream = file.InputStream;

                    IExcelDataReader reader = null;

                    if (file.FileName.EndsWith(".xls"))
                    {
                        reader = ExcelReaderFactory.CreateBinaryReader(stream);
                    }
                    else if (file.FileName.EndsWith(".xlsx"))
                    {
                        reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    }
                    else
                    {
                        message = "This file format is not supported";
                    }

                    DataSet excelRecords = reader.AsDataSet();
                    reader.Close();

                    var getSegment = excelRecords.Tables[0];
                    for (int i = 1; i < getSegment.Rows.Count; i++)
                    {
                        KalibrateSegmentStaging objUser = new KalibrateSegmentStaging();
                        objUser.SegmentId = System.Convert.ToInt32(getSegment.Rows[i][0]);
                        objUser.LXMarketId = System.Convert.ToInt32(getSegment.Rows[i][1]);
                        objUser.State = getSegment.Rows[i][2].ToString();
                        objUser.District = getSegment.Rows[i][3].ToString();
                        objUser.Ranking = System.Convert.ToDecimal(getSegment.Rows[i][4]);
                        objUser.TotalMOFUEL = System.Convert.ToInt32(getSegment.Rows[i][5]);
                        objUser.HighwayName = getSegment.Rows[i][6].ToString();
                        objUser.MinPointScore = System.Convert.ToDecimal(getSegment.Rows[i][7]);
                        objUser.MaxPointScore = System.Convert.ToDecimal(getSegment.Rows[i][8]);
                        objUser.AvgPointScore = System.Convert.ToDecimal(getSegment.Rows[i][9]);
                        objUser.SegmentLength = System.Convert.ToDecimal(getSegment.Rows[i][10]);
                        objUser.MidpointLatitude = System.Convert.ToDecimal(getSegment.Rows[i][11]);
                        objUser.MidpointLongitude = System.Convert.ToDecimal(getSegment.Rows[i][12]);
                        objUser.ROCount = System.Convert.ToInt32(getSegment.Rows[i][13]);
                        objUser.Address = getSegment.Rows[i][14].ToString();
                        objUser.Note1 = null;
                        objUser.Note2 = null;
                        System.DateTime today = System.DateTime.Today; // As DateTime
                        objUser.UploadedOn = today;
                        objEntity.KalibrateSegmentStagings.Add(objUser);

                    }

                    int output = objEntity.SaveChanges();
                    if (output > 0)
                    {
                        message = "Excel file has been successfully uploaded";
                    }
                    else
                    {
                        message = "Excel file uploaded has faild";
                    }

                }

                else
                {
                    result = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            return message;
        }

        [Route("SegmentDetails")]
        [HttpGet]
        public List<KalibrateSegmentStaging> BindUser()
        {
            List<KalibrateSegmentStaging> lstUser = new List<KalibrateSegmentStaging>();
            using (dbKalibrateEntities1 objEntity = new dbKalibrateEntities1())
            {
                lstUser = objEntity.KalibrateSegmentStagings.ToList();
            }
            return lstUser;
        }

    }
}
