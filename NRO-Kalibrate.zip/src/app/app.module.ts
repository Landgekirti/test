import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpParams } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { getData } from './components/services/getData.service';
import { FormsModule } from '@angular/forms'
import { ReactiveFormsModule } from '@angular/forms'
import 'hammerjs';
import {
  MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatButtonModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatSelectModule,
  MatTableModule,
  MatTabsModule,
  MatListModule,
  MatMenuModule,
  MatCheckboxModule,
  MatPaginatorModule,
  MatTooltipModule
} from '@angular/material';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { MatDialogModule, } from "@angular/material";
import { NgxPaginationModule } from 'ngx-pagination';
import { CookieService } from 'ngx-cookie-service';
import { MessageService } from './components/common/message.service'
import { ToastrModule } from 'ngx-toastr';
import { AgmCoreModule } from '@agm/core';
 
import { SegmentDetailComponent } from './components/segment-details/segment-details.component';
import { HeaderComponent } from './components/common/header/header.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { GrdFilterPipe1 } from './components/services/grd-filter.pipe';
import { LoginComponent } from './components/login/login.component';
import { ExcelUploadComponent } from './components/excel-upload/excel-upload.component';
import { MainKalibrateComponent } from './components/main-kalibrate/main-kalibrate.component';
import { PointsComparisonComponent } from './components/points-comparison/points-comparison.component';
import { proposalMapComponent } from './components/common/proposal-Map/proposal-Map.component';

@NgModule({
  declarations: [
    AppComponent,
    SegmentDetailComponent,
    HeaderComponent,
    FooterComponent,
    GrdFilterPipe1,
    LoginComponent,
    ExcelUploadComponent,
    MainKalibrateComponent,
    PointsComparisonComponent,
    proposalMapComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatTableModule,
    MatTabsModule,
    MatListModule,
    MatMenuModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatTooltipModule,
    NgxPaginationModule,
    MatDialogModule,
    ToastrModule.forRoot({
      positionClass: 'toast-top-right',
      closeButton: true,
    }),
    AgmCoreModule.forRoot({
      //apiKey : 'AIzaSyDyywjLFgCtDtjtFHUdk_lcgYotknilvpQ'
      apiKey: 'AIzaSyB7MZzEewcCDD5hTld7mjZ16CreRlG5f9Y'
    })
  ],
  providers: [getData, CookieService, MessageService],
  bootstrap: [AppComponent],
  entryComponents: [proposalMapComponent,ExcelUploadComponent, PointsComparisonComponent],

})
export class AppModule { }
