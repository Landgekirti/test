import { Component, OnInit, ViewChild, Input, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { getData } from '../Services/getData.service';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material';
import { MatFormFieldModule } from '@angular/material/form-field';
import { LocalSevice } from './../localservice.service'
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-segment-details',
  templateUrl: './segment-details.component.html',
  styleUrls: ['./segment-details.component.scss']
})
export class SegmentDetailComponent implements OnInit {
  States; Districts; //getDropdowns
  breadcrum = 'Segments'
  stateInput: String = null;
  DistrictsInput: String = null;
  NumberOfRecords: Number = 5; //Number of records oi list
  Records: {}
  SegmentsData;
  SelectedSegments;
  checked: boolean = false
  message: string;

  @Input() Searchseg
  searchText: any;
  length: Number

  constructor(private getSegmentsData: getData,
    private router: Router,
    private localSevice: LocalSevice,
    public dialogRef: MatDialogRef<SegmentDetailComponent>,
  ) { }

  ngOnInit() {
    this.searchText = this.Searchseg
    this.GetSegmentData()
    this.getState();
    this.getDistricts();
    this.getsegbyDistrict()
    this.Records = [{ "Value": 3 }, { "Value": 5 }, { "Value": 10 }, { "Value": 25 }, { "Value": 50 }, { "Value": 100 }]
  }

  getState() {
    this.getSegmentsData.getState().subscribe(data => {
      this.States = data.Table;
    });
  }

  getDistricts() {
    this.getSegmentsData.getDistrict(this.stateInput).subscribe(Distdata => {
      this.Districts = Distdata.Table;
      this.GetSegmentDatabyState();
    });
  }

  GetSegmentData() {
    this.getSegmentsData.GetSegmentData().subscribe(data => {
      this.SegmentsData = data.Table
      this.localSevice.allProposalsData = this.SegmentsData
    });
  }

  GetSegmentDatabyState() {
    this.getSegmentsData.GetSegmentDatabyState(this.stateInput).subscribe(data => {
      this.SegmentsData = data.Table;
      this.localSevice.state = this.stateInput;

    });
  }

  districts
  getsegbyDistrict() {
    this.districts = JSON.stringify(this.DistrictsInput)
    this.getSegmentsData.GetSegmentDatabyDistrict(this.DistrictsInput).subscribe(data => {
      this.SegmentsData = data.Table;
      this.localSevice.District = this.DistrictsInput;
    });
  }

  OnSelectSegments($event) {
    this.SelectedSegments = (this.SelectedSegments + ',' + $event)
  }

  onClose() {
    this.dialogRef.close();
  }

}

