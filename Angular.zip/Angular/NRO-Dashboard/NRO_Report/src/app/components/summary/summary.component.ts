import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription }   from 'rxjs';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
import { MatDialog, MatDialogConfig, MatSnackBar, MatDialogRef } from '@angular/material';
import { RegionDetailsComponent } from './region-details/region-details.component';
import { RegionDataService } from './region-data.service';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {
  showAll:string='show-class';
  obj;
  breadcrum="Summary"
  selectedTab:number=0;
  loaderVal:boolean=true;
  pieObjDiv="pieDiv"
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService,private MatDialog: MatDialog,public regionDataService:RegionDataService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
    
    this.getRegionData();
    
  }

  ngOnInit() {
    this.getHeight();
    $('#flipButton5').on('click', function() {
      $('#box5').toggleClass('flipped');
    });
  }

  ngAfterViewInit(){
    var logo = document.getElementsByTagName('title')
    
    
    for(let i=0;i<logo.length;i++){
      
    }
  }

  tabChanged(data){
    
    if(data.index==0){
      this.showAll='show-class';
    }
    else{
      this.showAll='hide-class';
    }

    

  }

 ngOnChange(){

}

  getHeight(){
    
    var heightArray1 = $(".set-height").map( function(){
                
                  return  $(this).height();

              }).get();
            
              var maxHeight = Math.max.apply( Math, heightArray1);
                  $(".set-height").height(maxHeight);
              }

reportDetails
objForPie=[]
getRegionData(){
  this.obj={
    "RegionCode": "North"
  }
  this.loaderVal=true
    this.httpService.getRegionSummary(this.obj).subscribe((response) => {
       
       
      this.reportDetails=response;
      this.reportDetails=this.reportDetails.Table
      this.loaderVal=false;
      for(let reportData of this.reportDetails){
        let keyValue
        keyValue=
         {
          "key":reportData.RegionName,
          "value":reportData.CompletedCount
         };
        reportData.piechartInput=keyValue;
        this.objForPie.push(keyValue);
        
      }
      this.reportDetails.pieObj=this.objForPie;
      
    }, (error) => {
        
    }
    );
  }

  callSummary(){
    this.router.navigate(['/nro-summarybar']);
  }

  regionData
  regionDetails(region,statecode){
    
    this.regionData={'RegionCode':region,'StatusCode':statecode}
    this.regionDataService.RegionData=this.regionData;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.panelClass='dialog-lg';
    let dialogRef= this.MatDialog.open(RegionDetailsComponent, dialogConfig);
    dialogRef.disableClose=true;
    dialogRef.afterClosed().subscribe((resp)=>
    {
            
    })
  }

  downloadData
  downloadExcel(){
    this.httpService.getExcel().subscribe((response) => {
       
       
      this.downloadData=response;
      this.onDownload();
    }, (error) => {
        
      this.downloadData=[]
    }
    );
  }

   


  onDownload() {
   
    let oDownloadList = [];
    let todaysDate = new Date();
    //let fileName: string = "Clause21.xlsx";
    let month = todaysDate.getMonth() + 1;
    let fileName = "NROCNPT_Report_" + todaysDate.getDate() + "_" + month + "_" + todaysDate.getFullYear() + '.xlsx';
    try {
      
      if (this.downloadData != null && this.downloadData.length > 0) {
        this.downloadData.forEach(element => {
          
          oDownloadList.push({
            'Proposal_Number': element.Proposal_Number,
            'RO_Code': element.RO_Code,
            'Region': element.Region,
            'Sh_Code': element.Sh_Code,
            'State': element.State,
            'BusinessState': element.BusinessState,
            'LocationName': element.LocationName,
            'Latitude': element.Latitude,
            'Longitude': element.Longitude,
            'District': element.District,
            'Category': element.Category,
            'Sub Category': element.Sub_Category,
            'RoadClassification':element.RoadClassification,
            'Operation': element.Operation,
            'RoadType': element.RoadType,
            'Carriageway': element.Carriageway,
            'Road_Name': element.Road_Name,
            'Road_Side': element.Road_Side,
            'Road_Sretch_From': element.Road_Sretch_From,
            'Road_Sretch_To': element.Road_Sretch_To,
            'Road_Sretch_KMS': element.Road_Sretch_KMS,
            'Desirable_Location': element.Desirable_Location,
            'DesirableFrom': element.DesirableFrom,
            'DesirableTo': element.DesirableTo,
            'DesirableLength': element.DesirableLength,
            'DesirableRoadSide': element.DesirableRoadSide,
            'Indicative_Land': element.Indicative_Land,
            'MinimumFrom': element.MinimumFrom,
            'MinimumTo': element.MinimumTo,
            'MinimumLength': element.MinimumLength,
            'MinimumRoadSide': element.MinimumRoadSide,
            'MS_Av_Throughput': element.MS_Av_Throughput,
            'HSD_Av_Throughput': element.HSD_Av_Throughput,
            'Total_Av_Throughput': element.Total_Av_Throughput,
            'MS_TA_Potential': element.MS_TA_Potential,
            'HSD_TA_Potential': element.HSD_TA_Potential,
            'Total_TA_Potential': element.Total_TA_Potential,
            'MS_ProjVol_Yr1': element.MS_ProjVol_Yr1,
            'HSD_ProjVol_Yr1': element.HSD_ProjVol_Yr1,
            'Total_ProjVol_Yr1': element.Total_ProjVol_Yr1,
            'MS_ProjVol_Yr3': element.MS_ProjVol_Yr3,
            'HSD_ProjVol_Yr3': element.HSD_ProjVol_Yr3,
            'Total_ProjVol_Yr3': element.Total_ProjVol_Yr3,
            'No_Of_RO': element.No_Of_RO,
            'ExtractionType':element.ExtractionType,
            'RationalForExtractionMethod':element.RationalForExtractionMethod,
            'ML_RecomdCase':element.ML_RecomdCase,
            'VolumeByExtraction_MS':element.VolumeByExtraction_MS,
            'VolumeByExtraction_HSD':element.VolumeByExtraction_HSD,
            'VolumeByME_MS':element.VolumeByME_MS,
            'VolumeByME_HSD':element.VolumeByME_HSD,
            'VolumeByML_HSD':element.VolumeByML_HSD,
            'VolumeByML_MS':element.VolumeByML_MS,
            'Projected_ME': element.Projected_ME,
            'Model': element.Model,
            'BaseModel': element.BaseModel,
            'DesirableFrontage':element.DesirableFrontage,
            'DesirableDepth':element.DesirableDepth,
            'MinimumFrontage':element.MinimumFrontage,
            'MinimumDepth':element.MinimumDepth,
            'SiteSpecificFrontage':element.SiteSpecificFrontage,
            'SiteSpecificDepth':element.SiteSpecificDepth,
            'SpecificMinFrontage':element.SpecificMinFrontage,
            'SpecificMinDepth':element.SpecificMinDepth,
            'SiteSpecificDesirableArea':element.SiteSpecificDesirableArea,
            'SiteSpecificMinimumArea':element.SiteSpecificMinimumArea,
            'MinimumArea':element.MinimumArea,
            'DesirableArea':element.DesirableArea,
            'Priority':element.Priority,
            'SubmittedBy': element.SubmittedBy,
            'SubmittedOn': element.SubmittedOn,
            'Approve_By_NDM': element.Approve_By_NDM,
            'Approve_Date_NDM': element.Approve_Date_NDM,
            'Approve_By_SBDM': element.Approve_By_SBDM,
            'Approve_Date_SBDM': element.Approve_Date_SBDM,
            'Approve_By_SH': element.Approve_By_SH,
            'Approve_Date_SH': element.Approve_Date_SH,
            'Approve_By_RSM': element.Approve_By_RSM,
            'Approve_By_NMM': element.Approve_By_NMM,
            'Approve_By_Head': element.Approve_By_Head,
            'Approve_By_CNPT': element.Approve_By_CNPT,
            'ROCodeGenDate': element.ROCodeGenDate,
            'Pending_With': element.Pending_With,
            'Status': element.Status,
            'Total_Query': element.Total_Query,
            'Open_Query': element.Open_Query,
            //'Approve_By_CNPT': element.Open Query
          })
        });
        const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(oDownloadList);

        ws['A1'].v = "Proposal_Number";
        ws['B1'].v = "RO_Code";
        ws['C1'].v = "Region";
        ws['D1'].v = "Sh_Code";
        ws['E1'].v = "State";
        ws['F1'].v = "BusinessState";
        ws['G1'].v = "LocationName";
        ws['H1'].v = "Latitude";
        ws['I1'].v = "Longitude";
        ws['J1'].v = "District";
        ws['K1'].v = "Category";
        ws['L1'].v = "Sub_Category";
        ws['M1'].v = "RoadClassification";
        ws['N1'].v = "Operation";
        ws['O1'].v = "RoadType";
        ws['P1'].v = "Carriageway";
        ws['Q1'].v = "Road_Name";
        ws['R1'].v = "Road_Side";
        ws['S1'].v = "Road_Sretch_From";
        ws['T1'].v = "Road_Sretch_To";
        ws['U1'].v = "Road_Sretch_KMS";
        ws['V1'].v = "Desirable_Location";
        ws['W1'].v = "DesirableFrom";
        ws['X1'].v = "DesirableTo";
        ws['Y1'].v = "DesirableLength";
        ws['Z1'].v = "DesirableRoadSide";
        ws['AA1'].v = "Indicative_Land";
        ws['AB1'].v = "MinimumFrom";
        ws['AC1'].v = "MinimumTo";
        ws['AD1'].v = "MinimumLength";
        ws['AE1'].v = "MinimumRoadSide";
        ws['AF1'].v = "MS_Av_Throughput";
        ws['AG1'].v = "HSD_Av_Throughput";
        ws['AH1'].v = "Total_Av_Throughput";
        ws['AI1'].v = "MS_TA_Potential";
        ws['AJ1'].v = "HSD_TA_Potential";
        ws['AK1'].v = "Total_TA_Potential";
        ws['AL1'].v = "MS_ProjVol_Yr1";
        ws['AM1'].v = "HSD_ProjVol_Yr1";
        ws['AN1'].v = "Total_ProjVol_Yr1";
        ws['AO1'].v = "MS_ProjVol_Yr3";
        ws['AP1'].v = "HSD_ProjVol_Yr3";
        ws['AQ1'].v = "Total_ProjVol_Yr3";
        ws['AR1'].v = "No_Of_RO";
        ws['AS1'].v = "ExtractionType";
        ws['AT1'].v = "RationalForExtractionMethod";
        ws['AU1'].v = "ML_RecomdCase";
        ws['AV1'].v = "VolumeByExtraction_MS";
        ws['AW1'].v = "VolumeByExtraction_HSD";
        ws['AX1'].v = "VolumeByME_MS";
        ws['AY1'].v = "VolumeByME_HSD";
        ws['AZ1'].v = "VolumeByML_HSD";
        ws['BA1'].v = "VolumeByML_MS";
        ws['BB1'].v = "Projected_ME";
        ws['BC1'].v = "Model";
        ws['BD1'].v = "BaseModel";
        ws['BE1'].v = "DesirableFrontage";
        ws['BF1'].v = "DesirableDepth";
        ws['BG1'].v = "MinimumFrontage";
        ws['BH1'].v = "MinimumDepth";
        ws['BI1'].v = "SiteSpecificFrontage";
        ws['BJ1'].v = "SiteSpecificDepth";
        ws['BK1'].v = "SpecificMinFrontage";
        ws['BL1'].v = "SpecificMinDepth";
        ws['BM1'].v = "SiteSpecificDesirableArea";
        ws['BN1'].v = "SiteSpecificMinimumArea";
        ws['BO1'].v = "MinimumArea";
        ws['BP1'].v = "DesirableArea"
        ws['BQ1'].v = "Priority";
        ws['BR1'].v = "SubmittedBy";
        ws['BS1'].v = "SubmittedOn";
        ws['BT1'].v = "Approve_By_NDM";
        ws['BU1'].v = "Approve_Date_NDM";
        ws['BV1'].v = "Approve_By_SBDM";
        ws['BW1'].v = "Approve_Date_SBDM";
        ws['BX1'].v = "Approve_By_SH";
        ws['BY1'].v = "Approve_Date_SH";
        ws['BZ1'].v = "Approve_By_RSM";
        ws['CA1'].v = "Approve_By_NMM";
        ws['CB1'].v = "Approve_By_Head";
        ws['CC1'].v = "Approve_By_CNPT";
        ws['CD1'].v = "ROCodeGenDate";
        ws['CE1'].v = "Pending_With";
        ws['CF1'].v = "Status";
        ws['CG1'].v = "Total_Query";
        ws['CH1'].v = "Open_Query";

        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        /* save to file */
        XLSX.writeFile(wb, fileName);
      }
      else {
       
      }
    } catch (error) {
      
    }
  }
}
