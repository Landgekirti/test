import { Component, OnInit } from '@angular/core';
import { NgwWowService } from 'ngx-wow';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { HttpCallsService } from '../../services/http-calls.service';
import { CountUpOptions } from 'countup.js';
import counterUp from 'counterup2'
declare const Waypoint: any;


@Component({
  selector: 'app-proposal',
  templateUrl: './proposal.component.html',
  styleUrls: ['./proposal.component.scss']
})
export class ProposalComponent implements OnInit {
  opts: CountUpOptions;
  loaderVal:boolean=true;
  current: Array<any> = [];
  max = 100;
  breadcrum="Proposal"
  obj;
  constructor(private router: Router, private wowService: NgwWowService,
    public httpService:HttpCallsService){
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
      // Reload WoW animations when done navigating to page,
      // but you are free to call it whenever/wherever you like
      this.wowService.init(); 
      
    });
  }

  ngOnInit() {
    $(function () {
      function equalHeight() {
        var heightArray = $(".white-box").map(function () {
          return $(this).height();
        }).get();
        var maxHeight = Math.max.apply(Math, heightArray);
        $(".white-box").height(maxHeight);
      }
      equalHeight();
    });
    this.getCounts();
  }

  ngAfterViewInit() {
    let element;
    for( let i = 0; i < 5; i++) {
      element = document.getElementById('forCount' + i);
      new Waypoint({
        element: element,
        handler: function () {
          counterUp(element);
          this.destroy();
        },
        offset: 'bottom-in-view'
      })
      counterUp(element, {
        duration: 1000,
        delay: 16
      })
    }
    // $('.current').each(function() {
    //   new Waypoint({
    //     element: this,
    //     handler: function () {
    //       counterUp(this);
    //       this.destroy();
    //     },
    //     offset: 'bottom-in-view'
    //   })
    // })
    // const element = document.querySelectorAll('.current');
    // for(var i = 0; i < element.length; i++) {
    //   new Waypoint({
    //     element: element[i],
    //     handler: function () {
    //         counterUp(element);
    //         this.destroy();
    //     },
    //     offset: 'bottom-in-view',
    //   })
    // }
  }

  // produceRandom() {
  //   for (let i = 0; i < 5; i++) {
  //     this.current[i] = Math.round(Math.random() * 1000)
  //   }
  // }
  reportDetails
  getCounts(){
    this.loaderVal=true;
    this.httpService.getIndiaSummary().subscribe((response) => {
          
          this.reportDetails=response;
          this.current=this.reportDetails.Table;
          this.loaderVal=false;
        }, (error) => {
            
        }
        );
  }

}
