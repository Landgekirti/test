﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Cors;
using System.Web.Http;
using System.Web.Http.Cors;


namespace SegmentUploadWebApp.Controllers
{
    [RoutePrefix("Api/getSegmentsData")] 
    public class getSegmentsDataController : ApiController
    {
        string ConnString = WebConfigurationManager.ConnectionStrings["KalibrateConn"].ConnectionString;

        [HttpPost]
        [Route("GetStates")]
        public DataSet GetState([FromBody]Filters State)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetStatesandDistricts", conn))
                {
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@filterType", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@filterType"].Value = State.filterType;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@filterValue", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@filterValue"].Value = State.filterValue;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

         [HttpPost]
         [Route("GetSegmentDatabyStatesandDistricts")]
        public DataSet GetSegmentDatabyState([FromBody]Filters State)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnString))
                using (SqlCommand cmd = new SqlCommand("spGetSegmentsbyStatesandDistricts", conn))
                {
                    
                    conn.Open();
                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@filterType", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@filterType"].Value = State.filterType;
                    adapt.SelectCommand.Parameters.Add(new SqlParameter("@FilterValue", SqlDbType.VarChar));
                    adapt.SelectCommand.Parameters["@FilterValue"].Value = State.filterValue;
                    DataSet ds = new DataSet();
                    adapt.Fill(ds);
                    DataTable dt = new DataTable();
                    dt = ds.Tables[0];
                    return ds;
                }
            }
            catch (Exception e)
            { throw e; }
        }

    }

}
public class Filters
{
    public string filterValue { get; set; }
    public string filterType { get; set; }
    public string StateInput { get; set; }

}